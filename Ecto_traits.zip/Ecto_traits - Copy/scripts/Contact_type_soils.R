#Model the relative abundances of exploration types ----

#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

require(dplyr)
require(tidyr)
require(data.table)
require(splitstackshape)
require(pls)
require(reshape2)
require(cowplot)

icp.dat <- read.csv(icp.data.envt)
isme.explorers.2 <- readRDS(isme.explore.2.new.fungal.traits)
isme.explorers <- readRDS(isme.explore)
soil.explorers <- readRDS(soil.explore)
soil.exploreres.2 <- readRDS(soil.explore.2.new.fungal.traits)

#Combine the env't and species matrices
isme.explorers.w.envt <- merge(soil.explorers, icp.dat, by = "country_plot")


#Now let's build the models to predict contact type relative abundances

#fit med. distance-fring model
c.m <- plsr(contact ~ n*Tree_type+p*Tree_type++OFH.Nitrogen.Stock+OFH.pH+mg_C_ha_yr+lat+N_dep_2019+Stand.age, data=isme.explorers.w.envt, 
            scale=TRUE, validation="CV", method = "oscorespls")

summary(c.m) 

#Visualize cross-validation plots
validationplot(c.m, val.type="MSEP")
hist(c.m$residuals)
qqnorm(c.m$residuals)

#look at variable importance in the projection scores (ViP)
VIP(c.m)

#What if we remove the least informative variables? - N stocks, lat, stand age, n*Tree_type
cm.2 <- plsr(contact ~ n*Tree_type + p*Tree_type + OFH.pH + lat, data=isme.explorers.w.envt, 
             scale=TRUE, validation="CV", method = "oscorespls")

summary(cm.2) 
summary(c.m)

#Visualize cross-validation plots
validationplot(cm.2, val.type="MSEP")
hist(cm.2$residuals)
qqnorm(cm.2$residuals)

#look at variable importance in the projection scores (ViP)
VIP(cm.2)
plot(cm.2, ncomp = 3, asp = 1, line = TRUE) #Looks quite bad!

#Now try to predict new observations
cm.2.predict <- predict(cm.2, ncomp = 2, newdata = isme.explorers.w.envt[1:50,], na.action = "na.omit")
cm.2.subset <- (isme.explorers.w.envt[rownames(isme.explorers.w.envt) %in% row.names(cm.2.predict), ])

#Now calculate the root mean sqare error (RMSE) - the average deviation between the predicted rel. abund. and observed
sqrt(mean((cm.2.predict - cm.2.subset$contact)^2))

#Now plot the VIF scores for Comp1 and 2
cm.2.2.vip <- data.frame(VIP(cm.2))
cm.f.2.vip.df <- data.frame(Comp = c(rep(c("Comp1","Comp2"), 7)),
                            Factor = c(rep("Foliar N", 2),  
                                       rep("Foliar P", 2), 
                                       rep("Tree type", 2), 
                                       rep("Soil pH", 2), 
                                       rep("Tree growth", 2), 
                                       rep("N deposition", 2),
                                       rep("Foliar P x tree type", 2)),
                            VIP = c(cm.2.2.vip$n[1:2], 
                                    cm.2.2.vip$p[1:2], 
                                    cm.2.2.vip$Tree_typeconifers[1:2], 
                                    cm.2.2.vip$OFH.pH[1:2], 
                                    cm.2.2.vip$mg_C_ha_yr[1:2],
                                    cm.2.2.vip$N_dep_2019[1:2],
                                    cm.2.2.vip$p.Tree_typeconifers[1:2]))

cm.f.vip.plot <- ggplot(cm.f.2.vip.df, aes(x = reorder(Factor,VIP), y = VIP, fill = Comp))+
  geom_bar(stat = 'identity')+
  theme_classic()+
  coord_flip()+
  labs(x = "", y = "Variable influence on projection")+
  scale_fill_manual(values = c("orange", "blue"))  

#And now visualize the main effects as scatterplots
fol.n <- ggplot(isme.explorers.w.envt, aes(x = log(n), y = 100*contact))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Contact type (%)", 
                         x = expression(paste("Foliar N levels (m", g^{-1},")")))+
  scale_color_manual(values = c("purple", "green"))+ facet_wrap(.~Tree_type, scales = "free")

N_dep <- ggplot(isme.explorers.w.envt, aes(x = N_dep_2019, y = 100*contact))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Contact type (%)", 
                         x = expression(paste("N deposition (mg N ", m^{2}," ", y^{-1},")")))+
  scale_color_manual(values = c("purple", "green"))  

tree_growth <- ggplot(isme.explorers.w.envt, aes(x = log(mg_C_ha_yr), y = 100*contact))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Contact type (%)", 
                         x = "Latitude")+
  scale_color_manual(values = c("purple", "green"))

#Bring it all together now
tog <- plot_grid(cm.f.vip.plot, fol.n, N_dep, tree_growth, ncol = 2)




