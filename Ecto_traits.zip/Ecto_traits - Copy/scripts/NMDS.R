#####Make an ordination comparing exploration type relative abundance links to the environment########


#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

require(dplyr)
require(tidyr)
require(data.table)
require(splitstackshape)
require(pls)
require(reshape2)
require(cowplot)
require(ggplot2)
require(chillR)
require(vegan)
require(psych)
require(ggrepel)
require(ape)

icp.dat <- read.csv(icp.data.envt)
isme.explorers.2 <- readRDS(isme.explore.2.new.fungal.traits)
isme.explorers <- readRDS(isme.explore)
soil.explorers <- readRDS(soil.explore)
soil.exploreres.2 <- readRDS(soil.explore.2.new.fungal.traits)

#Combine the env't and species matrices
soil.exploreres.with.envt <- merge(soil.explorers, icp.dat, by = "country_plot")
soil.exploreres.with.envt$Stand.age <- gsub(".9", ".0", soil.exploreres.with.envt$Stand.age)
soil.exploreres.with.envt$Stand.age <- as.numeric(as.character(soil.exploreres.with.envt$Stand.age))

#Split by horizon
soil.exploreres.with.envt.split <- split(soil.exploreres.with.envt, soil.exploreres.with.envt$Horizon)
soil.exploreres.with.envt.split$Org$pn <- soil.exploreres.with.envt.split$Org$p/soil.exploreres.with.envt.split$Org$n
#Now let's build the models to predict medium-distance fringe relative abundances

#Combine the env't and species matrices
isme.explorers.w.envt <- merge(isme.explorers, icp.dat, by = "country_plot")

#Fix stand age variable
isme.explorers.w.envt$Stand.age <- as.numeric(as.character(gsub(".9", ".0", isme.explorers.w.envt$Stand.age)))

#Make a new variable that is the foliar p:n ratio
isme.explorers.w.envt$p.n <- isme.explorers.w.envt$p/isme.explorers.w.envt$n


#Compare each group now and then make a matrix of each variable
ld <- plsr(log(0.01+long.distance) ~ log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + M01.pH + log(mg_C_ha_yr)*Tree_type + lat+ N_dep_2019 + Stand.age +
               MAT + MAP + clay_0.5cm_mean, 
               data=isme.explorers.w.envt, 
               scale=TRUE, validation="CV", method = "oscorespls")

mdf<- plsr(log(0.01+medium.distance_fringe) ~
          log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + M01.pH + log(mg_C_ha_yr)*Tree_type + lat+ N_dep_2019 + Stand.age +
          MAT + MAP + clay_0.5cm_mean, 
          data=isme.explorers.w.envt, 
          scale=TRUE, validation="CV", method = "oscorespls")

mds<- plsr(log(0.01+medium.distance_smooth) ~
          log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + M01.pH + log(mg_C_ha_yr)*Tree_type + lat+ N_dep_2019 + Stand.age +
          MAT + MAP + clay_0.5cm_mean, 
          data=isme.explorers.w.envt, 
          scale=TRUE, validation="CV", method = "oscorespls")

sdc<- plsr(log(0.01+short.distance_coarse) ~
             log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + M01.pH + log(mg_C_ha_yr)*Tree_type + lat+ N_dep_2019 + Stand.age +
             MAT + MAP + clay_0.5cm_mean, 
           data=isme.explorers.w.envt, 
           scale=TRUE, validation="CV", method = "oscorespls")

sdd<- plsr(log(0.01+short.distance_delicate) ~
             log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + M01.pH + log(mg_C_ha_yr)*Tree_type + lat+ N_dep_2019 + Stand.age +
             MAT + MAP + clay_0.5cm_mean, 
           data=isme.explorers.w.envt, 
           scale=TRUE, validation="CV", method = "oscorespls")

c.t<- plsr(log(0.01+contact) ~
             log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + M01.pH + log(mg_C_ha_yr)*Tree_type + lat+ N_dep_2019 + Stand.age +
             MAT + MAP + clay_0.5cm_mean, 
           data=isme.explorers.w.envt, 
           scale=TRUE, validation="CV", method = "oscorespls")

#Use the VIP scores for plotting variation across types
ld.vip <- data.frame(VIP(ld))
mdf.vip <- data.frame(VIP(mdf))
mds.vip <- data.frame(VIP(mds))
sdc.vip <- data.frame(VIP(sdc))
sdd.vip <- data.frame(VIP(sdd))
ct.vip <- data.frame(VIP(c.t))



##################################################################### #
#########Plot the main predictors across each ET######################
##################################################################### #

## 3 comps ----

#Now let's make one big DF
Group <- data.frame(ET = c(
  rep("LD", 3), 
  rep("MD-F", 3),
  rep("MD-S", 3),
  rep("SD-C", 3),
  rep("SD-D", 3),
  rep("C", 3)))

vips.grouped <- rbind(ld.vip[1:3,], mdf.vip[1:3,], mds.vip[1:3,], sdc.vip[1:3,], sdd.vip[1:3,], ct.vip[1:3,])
#

# NMDS ----
#Now make an NMDS of the vip scores
MDS.vips <- metaMDS(vips.grouped, distance = "bray") # great stress 0.1060272 
MDS.vips.scores <- data.frame(MDS.vips$points[,1:2])
MDS.vips.scores$ET <- Group$ET

#Now, let's grab the mean of MDS1 and MDS2 for each ET
MDS1.avg <- describeBy(MDS.vips.scores$MDS1, group = list(MDS.vips.scores$ET), mat = TRUE)
MDS2.avg <- describeBy(MDS.vips.scores$MDS2, group = list(MDS.vips.scores$ET), mat = TRUE)

NMDS.plot <- data.frame(NMDS1 = MDS1.avg$mean, NMDS2 = MDS2.avg$mean, NMDS1.se = MDS1.avg$sd, NMDS2.se = MDS2.avg$sd,
                        Group = MDS1.avg$group1)

#Now, I want to add the loadings of the "species", but not the interaction term because its too confusing
species.scores <- data.frame(MDS.vips$species[,1:2])
species.scores <- species.scores[1:12,]

#Clean-up the names
labie <- data.frame(Predictors = c("Foliar N", "Tree type", "Foliar P:N", "Soil N",
                                   "Soil pH", "Tree growth", "Latitude", "N dep.", "Stand age",
                                   "MAT", "MAP", "Soil clay"))
species.scores$Predictors <- labie$Predictors

NMDS.plot$Group <- factor(NMDS.plot$Group, levels = c("C", "MD-S", "SD-D", "MD-F","SD-C", "LD"))

#Now, let's plot everything
NMDS.fig <- ggplot(NMDS.plot, aes(x = NMDS1, y = NMDS2, color = Group))+
  geom_point()+
  #scale_color_manual(values = c("#e41a1c", "#377eb8","#4daf4a", "#984ea3","#ff7f00","#ffff33"))+
  scale_color_manual(values = c("#e41a1c", "#984ea3","#377eb8","#ff7f00","#4daf4a", "#ffff33"))+
  geom_errorbar(aes(ymax=NMDS2+NMDS2.se, ymin = NMDS2-NMDS2.se), width = 0)+
  geom_errorbarh(aes(xmax = NMDS1-NMDS1.se, xmin = NMDS1+NMDS1.se), height = 0)+
  theme_classic()+
  theme(legend.position = "top")+
  labs(color = "Exploration type")+
  theme(aspect.ratio = 1)

NMDS.fig 
# save as pdf 5.5 x 5.5 (just screenshot the pdf - it's better quality than making a jpg)

# Stacked plot ----
#Now make a figure that shows the top predictors across exploraton types in one single panel
vips.grouped.paired <- vips.grouped
colnames(vips.grouped.paired) <- c("Foliar N", "Tree type", "Foliar P:N", "Soil N", "Soil pH", "Tree growth", "Latitude",
                                   "N dep.", "Stand age", "MAT", "MAP", "Soil clay", "log.n..Tree_typeconifers", "Tree_typeconifers.log.p.n.", "Tree_typeconifers.log.mg_C_ha_yr.")
vips.grouped.paired$group <- Group$ET
vips.melt <- melt(vips.grouped.paired, id.vars = "group")
aggregate(breaks ~ wool + tension, data = warpbreaks, mean)
vips.melt.sum <- aggregate(value ~ group + variable, data = vips.melt, FUN = "sum")

#Now remove the interaction terms!
vips.melt.sum <- vips.melt.sum[!grepl("log.n..Tree_typeconifers",
                                      vips.melt.sum$variable),]

vips.melt.sum <- vips.melt.sum[!grepl("Tree_typeconifers.log.p.n.",
                                      vips.melt.sum$variable),]

vips.melt.sum <- vips.melt.sum[!grepl("Tree_typeconifers.log.mg_C_ha_yr.",
                                      vips.melt.sum$variable),]

vips.melt.sum$group <- factor(vips.melt.sum$group, levels = c("C", "SD-D", "SD-C", "MD-S", "MD-F", "LD"))

#Now, let's plot!
vip.score <- ggplot(vips.melt.sum, aes(y = reorder(variable, value), x = value, fill = group))+
  geom_bar(stat = 'identity', color = "black", show.legend = FALSE)+
  theme_classic()+
  coord_fixed()+
  scale_fill_manual(values = c("#e41a1c", "#377eb8","#4daf4a", "#984ea3","#ff7f00","#ffff33"))+
  labs(y = "", x = "ViP (sum of component 1, 2 & 3)", fill = "")

# combine plots ----

#Now plot them both together (not doing this now as not using stacked chart)
plot_grid(NMDS.fig, vip.score, ncol = 2, rel_widths = c(0.75, 1))
#
