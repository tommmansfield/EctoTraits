#Model the relative abundances of exploration types ----

#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

require(dplyr); require(tidyr); require(data.table); require(splitstackshape); require(pls)
require(reshape2); require(cowplot); require(ggplot2); require(chillR)

icp.dat <- read.csv(icp.data.envt)
isme.explorers.2 <- readRDS(isme.explore.2.new.fungal.traits)
isme.explorers <- readRDS(isme.explore)
soil.explorers <- readRDS(soil.explore)
soil.exploreres.2 <- readRDS(soil.explore.2.new.fungal.traits)
guilds.data <- readRDS(saprotroph.save)

#Combine the env't and species matrices
isme.explorers.w.envt <- merge(isme.explorers, icp.dat, by = "country_plot")

#Fix stand age variable
isme.explorers.w.envt$Stand.age <- as.numeric(as.character(gsub(".9", ".0", isme.explorers.w.envt$Stand.age)))

#Make a new variable that is the foliar p:n ratio
isme.explorers.w.envt$p.n <- isme.explorers.w.envt$p/isme.explorers.w.envt$n
#

#Match the guild data ----
guilds.data$country_plot <- soil.explorers$country_plot[match(row.names(guilds.data), row.names(soil.explorers))]
guilds.data$total.pathogens <- guilds.data$Plant.Pathogen + guilds.data$Plant.Pathogen.Wood.Saprotroph + guilds.data$Animal.Pathogen.Endophyte.Epiphyte.Plant.Pathogen+
  guilds.data$Animal.Pathogen.Endophyte.Plant.Pathogen.Wood.Saprotroph + guilds.data$Endophyte.Plant.Pathogen + guilds.data$Endophyte.Plant.Pathogen.Undefined.Saprotroph+
  guilds.data$Dung.Saprotroph.Plant.Pathogen + guilds.data$Leaf.Saprotroph.Plant.Pathogen.Undefined.Saprotroph.Wood.Saprotroph + guilds.data$Endophyte.Fungal.Parasite.Plant.Pathogen
  
guilds.data$total.saprotrophs <- guilds.data$Soil.Saprotroph + guilds.data$Dung.Saprotroph.Endophyte + guilds.data$Dung.Saprotroph.Endophyte.Wood.Saprotroph +
guilds.data$Dung.Saprotroph.Plant.Pathogen + guilds.data$Dung.Saprotroph.Wood.Saprotroph + guilds.data$Leaf.Saprotroph + guilds.data$Leaf.Saprotroph.Plant.Pathogen.Undefined.Saprotroph.Wood.Saprotroph+
  guilds.data$Leaf.Saprotroph.Wood.Saprotroph + guilds.data$Wood.Saprotroph + guilds.data$Litter.Saprotroph + guilds.data$Litter.Saprotroph.Soil.Saprotroph +
  guilds.data$Undefined.Saprotroph + guilds.data$Plant.Pathogen.Wood.Saprotroph + guilds.data$Fungal.Parasite.Soil.Saprotroph.Undefined.Saprotroph + guilds.data$Animal.Pathogen.Undefined.Saprotroph +
  guilds.data$Animal.Endosymbiont.Undefined.Saprotroph + guilds.data$Endophyte.Plant.Pathogen.Undefined.Saprotroph + guilds.data$Animal.Pathogen.Endophyte.Plant.Pathogen.Wood.Saprotroph

#Add these pathogen and saprotroph categories to the models
isme.explorers.w.envt$total.pathogens <- guilds.data$total.pathogens[match(isme.explorers.w.envt$country_plot, guilds.data$country_plot)]
isme.explorers.w.envt$total.saprotrophs <- guilds.data$total.saprotrophs[match(isme.explorers.w.envt$country_plot, guilds.data$country_plot)]


cor.test(inf2NA(log(isme.explorers.w.envt$medium.distance_fringe)), 
         inf2NA(log(isme.explorers.w.envt$total.pathogens)), use="pairwise.complete.obs")


ggplot(isme.explorers.w.envt, aes(y = log(medium.distance_fringe*100), x = log(100*total.pathogens)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Fungal pathogens log(%)", 
                         x = "Medium distance-fringe log(%)", fill = "")+
  scale_color_manual(values = c("purple", "green"))



#Now let's build the models to predict medium-distance fringe relative abundances ----

#fit med. distance-fringe model
md.f <- plsr(medium.distance_fringe ~ log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + M01.pH + log(mg_C_ha_yr)*Tree_type + lat+ N_dep_2019 + Stand.age +
               MAT + MAP + clay_0.5cm_mean, 
             data=isme.explorers.w.envt, 
             scale=TRUE, validation="CV", method = "oscorespls")

summary(md.f) 

#Visualize cross-validation plots
validationplot(md.f, val.type="MSEP")
hist(md.f$residuals)
qqnorm(md.f$residuals)

#look at variable importance in the projection scores (ViP)
VIP(md.f)

# What if we remove the least informative variables ViP < 0.8 on Comp 1-3?   
# soil pH, stand age, MAP, clay, tree type x tree growth
md.f.2 <- plsr(medium.distance_fringe ~ log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + log(mg_C_ha_yr) + lat+ N_dep_2019 +
                 MAT,
                  data=isme.explorers.w.envt, 
                  scale=TRUE, validation="CV", method = "oscorespls")

summary(md.f.2) 
summary(md.f)

#Visualize cross-validation plots
validationplot(md.f.2, val.type="MSEP")
hist(md.f.2$residuals)
qqnorm(md.f.2$residuals)

#look at variable importance in the projection scores (ViP)
VIP(md.f.2)
plot(md.f.2, ncomp = 3, asp = 1, line = TRUE) #Looks quite good!

#Now try to predict new observations
md.f.2.predict <- predict(md.f.2, ncomp = 3, newdata = isme.explorers.w.envt[1:50,], na.action = "na.omit")
md.f.2.subset <- (isme.explorers.w.envt[rownames(isme.explorers.w.envt) %in% row.names(md.f.2.predict), ])

#Now calculate the root mean sqare error (RMSE) - the average deviation between the predicted rel. abund. and observed
sqrt(mean((md.f.2.predict - md.f.2.subset$medium.distance_fringe)^2))

#Now plot the VIF scores for Comps 1, 2, and 3
md.f.2.vip <- data.frame(VIP(md.f.2))
md.f.2.vip.df <- data.frame(Comp = c(rep(c("Comp1","Comp2", "Comp3"), 10)),
                            Factor = c(rep("Foliar N", 3),
                                       rep("Tree type", 3), 
                                       rep("Foliar P:N", 3), 
                                       rep("Soil N", 3),
                                       rep("Forest productivity", 3), 
                                       rep("Latitude", 3), 
                                       rep("N deposition", 3), 
                                       rep("Mean annual temperature", 3),
                                       rep("Foliar N x Tree type", 3), 
                                       rep("Foliar P:N x Tree type", 3)),
                            VIP = c(md.f.2.vip$log.n.[1:3],
                                    md.f.2.vip$Tree_typeconifers[1:3],
                                    md.f.2.vip$log.p.n.[1:3],
                                    md.f.2.vip$log.Mineral.Nitrogen.Stock.[1:3],
                                    md.f.2.vip$log.mg_C_ha_yr.[1:3],
                                    md.f.2.vip$lat[1:3],
                                    md.f.2.vip$N_dep_2019[1:3],
                                    md.f.2.vip$MAT[1:3],
                                    md.f.2.vip$log.n..Tree_typeconifers[1:3],
                                    md.f.2.vip$Tree_typeconifers.log.p.n.[1:3]))

md.f.vip.plot <- ggplot(md.f.2.vip.df, aes(x = reorder(Factor,VIP), y = VIP))+
  geom_bar(stat = 'identity', show.legend = FALSE)+
  theme_classic()+
  coord_flip()+
  labs(x = "", y = "")+
  scale_fill_manual(values = c("orange", "blue"))  


# DON'T RUN THIS UNLESS MAKING THE PLOTS FOR A PANEL AND NEEDING TO GO TO THE NEXT SCRIPT!!!!!
# For plotting purposes only since making the plots from multiple scripts:
# rm(list=setdiff(ls(), c("cm.f.vip.plot", "sd.d.vip.plot", "sd.c.vip.plot", 
#                        "md.s.vip.plot", "md.f.vip.plot", "lm.vip.plot")))


# Get stats! ----

#Now split these out by tree type to isolate the conifer effects
isme.explorers.w.envt.sp <- split(isme.explorers.w.envt, isme.explorers.w.envt$Tree_type)

#this function will remove infinite values
inf2NA <- function(x) { x[is.infinite(x)] <- NA; x }

# check tree type comparison
kruskal.test(isme.explorers.w.envt$medium.distance_fringe, isme.explorers.w.envt$Tree_type)

# broad:conifer ratio = 0.2693898
mean(isme.explorers.w.envt.sp$broadleaves$medium.distance_fringe)/mean(isme.explorers.w.envt.sp$conifers$medium.distance_fringe)


# medium.distance_fringe ~ log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + log(mg_C_ha_yr) + lat+ log(N_dep_2019) + MAT


# Broadleaves
cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$medium.distance_fringe)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$n)), use="pairwise.complete.obs")# cor 0.6554525 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$medium.distance_fringe)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$p.n)), use="pairwise.complete.obs")# cor -0.2151915 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$medium.distance_fringe)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$Mineral.Nitrogen.Stock)), use="pairwise.complete.obs")# cor -0.1210274 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$medium.distance_fringe)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$mg_C_ha_yr)), use="pairwise.complete.obs")# cor -0.1638303 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$medium.distance_fringe)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$lat)), use="pairwise.complete.obs")# cor 0.2022858 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$medium.distance_fringe)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$N_dep_2019)), use="pairwise.complete.obs")# cor -0.09890048 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$medium.distance_fringe)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$MAT)), use="pairwise.complete.obs")# cor 0.08083215 (n/s)

# Conifers
cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$medium.distance_fringe)), 
         scale(log(isme.explorers.w.envt.sp$conifers$n)), use="pairwise.complete.obs")# cor -0.265214 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$medium.distance_fringe)), 
         scale(log(isme.explorers.w.envt.sp$conifers$p.n)), use="pairwise.complete.obs")# cor 0.3406184 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$medium.distance_fringe)), 
         scale(log(isme.explorers.w.envt.sp$conifers$Mineral.Nitrogen.Stock)), use="pairwise.complete.obs")# cor -0.4966992 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$medium.distance_fringe)), 
         scale(log(isme.explorers.w.envt.sp$conifers$mg_C_ha_yr)), use="pairwise.complete.obs")# cor -0.3158384 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$medium.distance_fringe)), 
         scale(log(isme.explorers.w.envt.sp$conifers$lat)), use="pairwise.complete.obs")# cor 0.4255678 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$medium.distance_fringe)), 
         scale(log(isme.explorers.w.envt.sp$conifers$N_dep_2019)), use="pairwise.complete.obs")# cor -0.5432443 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$medium.distance_fringe)), 
         scale(log(isme.explorers.w.envt.sp$conifers$MAT)), use="pairwise.complete.obs")# cor -0.1076227 (n/s)


#Get stats! (original)
#cor.test(inf2NA(log10(isme.explorers.w.envt.sp$conifers$medium.distance_fringe)), 
#scale(log10(isme.explorers.w.envt.sp$conifers$mg_C_ha_yr)), use="pairwise.complete.obs")

#cor.test(inf2NA(log10(isme.explorers.w.envt.sp$conifers$medium.distance_fringe)), 
#scale(isme.explorers.w.envt.sp$conifers$lat), use="pairwise.complete.obs")

#cor.test(inf2NA(log10), 
#scale(log10(isme.explorers.w.envt.sp$conifers$n)), use="pairwise.complete.obs")

#cor.test(inf2NA(log10(isme.explorers.w.envt.sp$conifers$medium.distance_fringe)), 
#scale(log10(isme.explorers.w.envt.sp$conifers$p.n)), use="pairwise.complete.obs")

#cor.test(inf2NA(log10(isme.explorers.w.envt.sp$conifers$medium.distance_fringe)), 
#scale(log10(isme.explorers.w.envt.sp$conifers$N_dep_2019)), use="pairwise.complete.obs")


#And now visualize the main effects ----
#This is  really just for confiers
growth <- ggplot(isme.explorers.w.envt.sp$conifers, aes(x = scale(log(mg_C_ha_yr)), y = log10(100*medium.distance_fringe)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Medium distance-fringe log(%)", 
                         x = expression(paste("Tree growth scaled(t C h", a^{-1}," y", r^{-1}, ")")), fill = "")+
  # scale_color_manual(values = c("purple", "green"))+
  scale_color_manual(values = c("green"))+
  theme(aspect.ratio = 1)

#This is really just for conifers
Lat <- ggplot(isme.explorers.w.envt.sp$conifers, aes(x = scale(lat), y = log10(100*medium.distance_fringe)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Medium distance-fringe log(%)", 
                         x = "Latitude (scaled)")+
  # scale_color_manual(values = c("purple", "green"))+
  scale_color_manual(values = c("green"))+
  theme(aspect.ratio = 1)

tree_type <- ggplot(isme.explorers.w.envt, aes(x = Tree_type, y = 100*medium.distance_fringe))+
  geom_boxplot(aes(color = Tree_type), show.legend = FALSE)+
  theme_classic() + labs(color = "",
                         y = "Medium distance-fringe (%)", 
                         x = "")+
  scale_color_manual(values = c("purple", "green"))+
  coord_flip()+
  theme(aspect.ratio = 1)

fol.n <- ggplot(isme.explorers.w.envt.sp$conifers, aes(x = scale(log10(n)), y = log10(100*medium.distance_fringe)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(aes(group = Tree_type), method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Medium distance-fringe log(%)", 
                         x = expression(paste("Foliar N scaled(m", g^{-1}," ", g^{-1},")")))+
  # scale_color_manual(values = c("purple", "green"))+
  scale_color_manual(values = c("green"))+
  theme(aspect.ratio = 1)

fol.p.n <- ggplot(isme.explorers.w.envt.sp$conifers, aes(x = scale(log10(p.n)), y = log10(100*medium.distance_fringe)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Medium distance-fringe log(%)", 
                         x = expression(paste("Foliar P:N scaled(m", g^{-1}," ", g^{-1},")")))+
  # scale_color_manual(values = c("purple", "green"))+
  scale_color_manual(values = c("green"))+
  theme(aspect.ratio = 1)


N.dep <- ggplot(isme.explorers.w.envt.sp$conifers, aes(x = scale((N_dep_2019)), y = log10(100*medium.distance_fringe)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Medium distance-fringe log(%)", 
                         x = expression(paste("N dep. scaled(mg N ", m^{2}," ", y^{-1},")")))+
  # scale_color_manual(values = c("purple", "green"))+
  scale_color_manual(values = c("green"))+
  theme(aspect.ratio = 1)

#Bring it all together now
row.1 <- plot_grid(tree_type, Lat, ncol = 2)
row.2 <- plot_grid(N.dep, growth, ncol = 2)
row.3 <- plot_grid(fol.p.n, fol.n, ncol = 2)
med.results <- plot_grid(row.1, row.2, row.3, ncol = 1)




#Now show the foliar N and P results but seperate them to fit different line tyes ----
isme.explorers.w.envt.sp <- split(isme.explorers.w.envt, isme.explorers.w.envt$Tree_type)
isme.explorers.w.envt.sp.sp <- split(isme.explorers.w.envt.sp$conifers, isme.explorers.w.envt.sp$conifers$Tree_species)

con.doms <- rbind(isme.explorers.w.envt.sp.sp$`Pinus sylvestris*`,
isme.explorers.w.envt.sp.sp$`Picea abies (P. excelsa)*`)

fol.N <- ggplot(con.doms, aes(y = log(n), x = 100*medium.distance_fringe, color = Tree_species))+
  geom_point(show.legend = FALSE)+
  geom_smooth(aes(group = Tree_species), method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         x = "Medium distance-fringe (%)", 
                         y = expression(paste("Foliar N levels log(m", g^{-1}," ", g^{-1},")")))+
  scale_color_manual(values = c("goldenrod", "green"))+
  theme(legend.position = "bottom")+
  theme(aspect.ratio = 1)

fol.P.N <- ggplot(con.doms, aes(y = log((p/n)), x = 100*medium.distance_fringe, color = Tree_species))+
  geom_point(show.legend = FALSE)+
  geom_smooth(aes(group = Tree_species), method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         x = "Medium distance-fringe (%)", 
                         y = expression(paste("Foliar P:N ratio log(m", g^{-1}," ", g^{-1},")")))+
  scale_color_manual(values = c("goldenrod", "green"))+
  theme(legend.position = "bottom")+
  theme(aspect.ratio = 1)

SOC.stock <- ggplot(con.doms, aes(y = log(M01.C.stock.w.o.c), x = 100*medium.distance_fringe, color = Tree_species))+
  geom_point(show.legend = FALSE)+
  geom_smooth(aes(group = Tree_species), method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         x = "Medium distance-fringe (%)", 
                         y = expression(paste("Soil C stock log(t C h", a^{-1}, ")")))+
  scale_color_manual(values = c("goldenrod", "green"))+
  theme(aspect.ratio = 1)

growth <- ggplot(con.doms, aes(y = log(kg_yr), x = 100*medium.distance_fringe, color = Tree_species))+
  geom_point(show.legend = TRUE)+
  geom_smooth(aes(group = Tree_species), method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         x = "Medium distance-fringe (%)", 
                         y = expression(paste("Tree growth log(kg C ", y^{-1}, ")")))+
  scale_color_manual(values = c("goldenrod", "green"))+
  theme(aspect.ratio = 1)

plot_grid(growth, fol.N, fol.P.N, ncol = 3)


