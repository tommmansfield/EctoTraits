#Plot pfam indicator species rsults

#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

#Load packages
require(ggplot2)
require(dplyr)

#Load data frame
pfma.results <- read.csv(pfam.indicators.save.string)

#Set axis order
pfma.results$Exploration <- factor(pfma.results$Exploration, levels = c("C", "SD", "MD-Smooth", "MD-Fringe", "LD"))

#Now plot!
Groups <- ggplot(pfma.results, aes(x = Function, y = Stat, fill = Exploration, color = Exploration))+
  geom_bar(stat = 'identity', show.legend = FALSE)+
  facet_wrap(. ~ Group, scales = "free", ncol = 1)+
  scale_fill_manual(values = c("aquamarine4", "cadetblue1", "darkorchid", "darkslateblue", "coral2"))+
  scale_color_manual(values = c("aquamarine4", "cadetblue1", "darkorchid", "darkslateblue", "coral2"))+
  coord_flip()+
  theme_classic() + theme(strip.background = element_blank(), strip.text = element_blank())+
  labs(y = "Indicator value", x = "", fill = "")+
  theme(legend.position = "bottom")


cowplot::plot_grid(cowplot::plot_grid(pfam.bray, Groups, ncol = 2),
cowplot::plot_grid(decomp.pfam.results, nitrogen.pfam.results, ncol = 2), ncol = 1, rel_heights = c(1, 0.7))



