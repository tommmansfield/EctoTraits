#Model the relative abundances of exploration types ----

#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

require(dplyr); require(tidyr); require(data.table); require(splitstackshape); require(pls)
require(reshape2); require(cowplot); require(ggplot2); require(chillR)

icp.dat <- read.csv(icp.data.envt)
isme.explorers.2 <- readRDS(isme.explore.2.new.fungal.traits)
isme.explorers <- readRDS(isme.explore)
soil.explorers <- readRDS(soil.explore)
soil.exploreres.2 <- readRDS(soil.explore.2.new.fungal.traits)


#Combine the env't and species matrices
isme.explorers.w.envt <- merge(isme.explorers, icp.dat, by = "country_plot")

#Fix stand age variable
isme.explorers.w.envt$Stand.age <- as.numeric(as.character(gsub(".9", ".0", isme.explorers.w.envt$Stand.age)))

#Make a new variable that is the foliar p:n ratio
isme.explorers.w.envt$p.n <- isme.explorers.w.envt$p/isme.explorers.w.envt$n

#Now let's build the models to predict long distance relative abundances ----

#fit long distance model
lm <- plsr(long.distance ~ log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + M01.pH + log(mg_C_ha_yr)*Tree_type + lat+ N_dep_2019 + Stand.age +
               MAT + MAP + clay_0.5cm_mean, 
             data=isme.explorers.w.envt, 
             scale=TRUE, validation="CV", method = "oscorespls")

summary(lm) 

#Visualize cross-validation plots
validationplot(lm, val.type="MSEP")
hist(lm$residuals)
qqnorm(lm$residuals)

#look at variable importance in the projection scores (ViP)
VIP(lm)

# What if we remove the least informative variables ViP < 0.8 on Comp 1-3?   
# tree type, tree growth, lat, stand age, MAT, clay, n*tree type, p:n*Tree type
lm.2 <- plsr(long.distance ~ log(n) + log(p.n) + log(Mineral.Nitrogen.Stock) + M01.pH + log(mg_C_ha_yr)*Tree_type + N_dep_2019 + MAP, 
               data=isme.explorers.w.envt, 
               scale=TRUE, validation="CV", method = "oscorespls")

summary(lm.2) 
summary(lm)

#Visualize cross-validation plots
validationplot(lm.2, val.type="MSEP")
hist(lm.2$residuals)
qqnorm(lm.2$residuals)

#look at variable importance in the projection scores (ViP)
VIP(lm.2)
plot(lm.2, ncomp = 3, asp = 1, line = TRUE) #It's ok

#Now try to predict new observations
lm.2.predict <- predict(lm.2, ncomp = 3, newdata = isme.explorers.w.envt[1:50,], na.action = "na.omit")
lm.2.subset <- (isme.explorers.w.envt[rownames(isme.explorers.w.envt) %in% row.names(lm.2.predict), ])

#Now calculate the root mean sqare error (RMSE) - the average deviation between the predicted rel. abund. and observed
sqrt(mean((lm.2.predict - lm.2.subset$long.distance)^2))

#Now plot the VIF scores for Comps 1, 2, and 3
lm.2.vip <- data.frame(VIP(lm.2))
lm.2.vip.df <- data.frame(Comp = c(rep(c("Comp1","Comp2", "Comp3"), 9)),
                            Factor = c(rep("Foliar N", 3),
                                       rep("Foliar P:N", 3), 
                                       rep("Soil N stocks", 3), 
                                       rep("Soil pH", 3),
                                       rep("Forest productivity", 3), 
                                       rep("Tree type", 3), 
                                       rep("N deposition", 3),
                                       rep("Mean annual precipitation", 3),
                                       rep("Forest productivity x Tree type", 3)),
                            VIP = c(lm.2.vip$log.n.[1:3],
                                    lm.2.vip$log.p.n.[1:3],
                                    lm.2.vip$log.Mineral.Nitrogen.Stock.[1:3],
                                    lm.2.vip$M01.pH[1:3],
                                    lm.2.vip$log.mg_C_ha_yr.[1:3],
                                    lm.2.vip$Tree_typeconifers[1:3],
                                    lm.2.vip$N_dep_2019[1:3],
                                    lm.2.vip$MAP[1:3],
                                    lm.2.vip$log.mg_C_ha_yr..Tree_typeconifers[1:3]))

lm.vip.plot <- ggplot(lm.2.vip.df, aes(x = reorder(Factor,VIP), y = VIP))+
  geom_bar(stat = 'identity', show.legend = FALSE)+
  theme_classic()+
  coord_flip()+
  labs(x = "", y = "ViP")+
  scale_fill_manual(values = c("orange", "blue"))  



# DON'T RUN THIS UNLESS MAKING THE PLOTS FOR A PANEL AND NEEDING TO GO TO THE NEXT SCRIPT!!!!!
# For plotting purposes only since making the plots from multiple scripts:
# rm(list=setdiff(ls(), c("cm.f.vip.plot", "sd.d.vip.plot", "sd.c.vip.plot", 
#                        "md.s.vip.plot", "md.f.vip.plot", "lm.vip.plot")))

# ViP plot panel ----

# two columns of C, SD-D, SD-C and MD-S, MD-F, LD
# add a-f labels with ETs e.g. a) C

VIP.panel <- plot_grid(cm.f.vip.plot, md.s.vip.plot, sd.d.vip.plot, 
                        md.f.vip.plot, sd.c.vip.plot, lm.vip.plot, 
                       #labels = c('a) C', 'b) MD-S', 'c) SD-D',
                       #           'd) MD-F', 'e) SD-C', 'f) LD'),
                       align = "hv",
                       ncol = 2)
VIP.panel
# save as pdf 7x7 portrait
# going to manually add the labels in because these just overlap everywhere

# Some notes on what needs improvement:
# 1) Make environmental condition names consistent
# 2) Can remove ViP from all but the bottom 2 (make it VIP instead??) - bottom 2 = SD-C and LD
# 3) re-order so that the left column is close distance, and the right column is exploratory
# 4) then manually put labels in in ppt





# Get stats! ----

#Now split these out by tree type to isolate the conifer effects
isme.explorers.w.envt.sp <- split(isme.explorers.w.envt, isme.explorers.w.envt$Tree_type)


#this function will remove infinite values
inf2NA <- function(x) { x[is.infinite(x)] <- NA; x }

# check tree type comparison
kruskal.test(isme.explorers.w.envt$long.distance, isme.explorers.w.envt$Tree_type)

# broad:conifer ratio = 1.531167
mean(isme.explorers.w.envt.sp$broadleaves$long.distance)/mean(isme.explorers.w.envt.sp$conifers$long.distance)


# long.distance ~ log(n) + log(p.n) + log(Mineral.Nitrogen.Stock) + lat + M01.pH + log(mg_C_ha_yr)*Tree_type + N_dep_2019 + MAP

# Broadleaves
cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$n)), use="pairwise.complete.obs")# cor 0.1147093 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$p.n)), use="pairwise.complete.obs")# cor -0.08976528 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$Mineral.Nitrogen.Stock)), use="pairwise.complete.obs")# cor -0.3005467 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$lat)), use="pairwise.complete.obs")# cor 0.06081532 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$M01.pH)), use="pairwise.complete.obs")# cor -0.4521813 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$mg_C_ha_yr)), use="pairwise.complete.obs")# cor -0.3576275 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$N_dep_2019)), use="pairwise.complete.obs")# cor 0.3010514 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$MAP)), use="pairwise.complete.obs")#cor -0.1079622 (n/s)

# Conifers
cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$n)), use="pairwise.complete.obs")# cor 0.1768683 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$p.n)), use="pairwise.complete.obs")# cor -0.02308193 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$Mineral.Nitrogen.Stock)), use="pairwise.complete.obs")# cor 0.1051869 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$lat)), use="pairwise.complete.obs")# cor 0.0960612 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$M01.pH)), use="pairwise.complete.obs")# cor -0.05898006 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$mg_C_ha_yr)), use="pairwise.complete.obs")# cor -0.171634 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$N_dep_2019)), use="pairwise.complete.obs")# cor 0.1436613 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$long.distance*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$MAP)), use="pairwise.complete.obs")# cor -0.06257026 (n/s)




#And now visualize the main effects ----

#N stock -- only significant for broadleaves!
Nstock <- ggplot(isme.explorers.w.envt, aes(x = scale((Mineral.Nitrogen.Stock)), y = log(0.01+long.distance)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Long distance log(%)", 
                         x = expression(paste("Soil N stock scaled(t N h", a^{-1},")")), fill = "")+
  scale_color_manual(values = c("purple", "green"))+
  theme(aspect.ratio = 1)+
  facet_wrap(.~Tree_type)

#Soil pH -- only significant for broadleaves!
pH <- ggplot(isme.explorers.w.envt, aes(x = scale(M01.pH), y = log(0.01+long.distance)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Long distance log(%)", 
                         x = "Soil pH (scaled)")+
  scale_color_manual(values = c("purple", "green"))+
  theme(aspect.ratio = 1)+
  facet_wrap(.~Tree_type)

tree_type <- ggplot(isme.explorers.w.envt, aes(x = Tree_type, y = 100*long.distance))+
  geom_boxplot(aes(color = Tree_type), show.legend = FALSE)+
  theme_classic() + labs(color = "",
                         y = "Long distance (%)", 
                         x = "")+
  scale_color_manual(values = c("purple", "green"))+
  coord_flip()+
  theme(aspect.ratio = 1)

fol.n <- ggplot(isme.explorers.w.envt, aes(x = scale(log(n)), y = log(long.distance)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(aes(group = Tree_type), method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Long distance log(%)", 
                         x = expression(paste("Foliar N levels scaled(m", g^{-1}," ", g^{-1},")")))+
  scale_color_manual(values = c("purple","green"))+ 
  theme(aspect.ratio = 1)+
  facet_wrap(.~Tree_type)

fol.p.n <- ggplot(isme.explorers.w.envt, aes(x = scale(log(p.n)), y = log(100*long.distance)))+
  geom_point(aes(color = Tree_type), show.legend = TRUE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Long distance log(%)", 
                         x = expression(paste("Foliar P:N levels scaled(m", g^{-1}," ", g^{-1},")")))+
  scale_color_manual(values = c("purple","green"))+ 
  theme(aspect.ratio = 1)+
  facet_wrap(.~Tree_type)

growth <- ggplot(isme.explorers.w.envt, aes(x = scale(log(mg_C_ha_yr)), y = log(100*long.distance)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Long distance log(%)", 
                         x = expression(paste("Tree growth scaled(t C h", a^{-1}," y", r^{-1}, ")")), fill = "")+
  scale_color_manual(values = c("purple","green"))+
  theme(aspect.ratio = 1)+
  facet_wrap(.~Tree_type)

map <- ggplot(isme.explorers.w.envt, aes(x = scale((MAP)), y = log(100*long.distance)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Long distance log(%)", 
                         x = "Mean annual precipitation", fill = "")+
  scale_color_manual(values = c("purple","green"))+
  theme(aspect.ratio = 1)+
  facet_wrap(.~Tree_type)

#Bring it all together now
row.1 <- plot_grid(lm.vip.plot, tree_type, ncol = 2)
row.2 <- plot_grid(growth, Lat, ncol = 2)
row.3 <- plot_grid(fol.p.n, fol.n, ncol = 2)
long.results <- plot_grid(row.1, row.2, row.3, ncol = 1)




#Now show the foliar N and P results but seperate them to fit different line tyes ----
isme.explorers.w.envt.sp <- split(isme.explorers.w.envt, isme.explorers.w.envt$Tree_type)
isme.explorers.w.envt.sp.sp <- split(isme.explorers.w.envt.sp$conifers, isme.explorers.w.envt.sp$conifers$Tree_species)

con.doms <- rbind(isme.explorers.w.envt.sp.sp$`Pinus sylvestris*`,
                  isme.explorers.w.envt.sp.sp$`Picea abies (P. excelsa)*`)

fol.N <- ggplot(con.doms, aes(y = log(n), x = 100*long.distance, color = Tree_species))+
  geom_point(show.legend = FALSE)+
  geom_smooth(aes(group = Tree_species), method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         x = "Long distance (%)", 
                         y = expression(paste("Foliar N levels log(m", g^{-1}," ", g^{-1},")")))+
  scale_color_manual(values = c("goldenrod", "green"))+
  theme(legend.position = "bottom")+
  theme(aspect.ratio = 1)

fol.P.N <- ggplot(con.doms, aes(y = log((p/n)), x = 100*long.distance, color = Tree_species))+
  geom_point(show.legend = FALSE)+
  geom_smooth(aes(group = Tree_species), method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         x = "Long distance (%)", 
                         y = expression(paste("Foliar P:N ratio log(m", g^{-1}," ", g^{-1},")")))+
  scale_color_manual(values = c("goldenrod", "green"))+
  theme(legend.position = "bottom")+
  theme(aspect.ratio = 1)

SOC.stock <- ggplot(con.doms, aes(y = log(M01.C.stock.w.o.c), x = 100*long.distance, color = Tree_species))+
  geom_point(show.legend = FALSE)+
  geom_smooth(aes(group = Tree_species), method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         x = "Long distance (%)", 
                         y = expression(paste("Soil C stock log(t C h", a^{-1}, ")")))+
  scale_color_manual(values = c("goldenrod", "green"))+
  theme(aspect.ratio = 1)

growth <- ggplot(con.doms, aes(y = log(kg_yr), x = 100*long.distance, color = Tree_species))+
  geom_point(show.legend = TRUE)+
  geom_smooth(aes(group = Tree_species), method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         x = "Long distance (%)", 
                         y = expression(paste("Tree growth log(kg C ", y^{-1}, ")")))+
  scale_color_manual(values = c("goldenrod", "green"))+
  theme(aspect.ratio = 1)

plot_grid(growth, fol.N, fol.P.N, ncol = 3)
