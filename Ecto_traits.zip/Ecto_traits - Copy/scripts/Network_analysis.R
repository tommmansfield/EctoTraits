#Make interaction network of EMF ETs and then test if communities differ between tree types

#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

require(fungaltraits)
require(igraph)
require(dplyr)
require(cooccur)
require(ggplot2)
require(ggraph)
require(cowplot)
require(splitstackshape)
require(vegan)

otu.tab <- read.csv(isme.ectos, row.names = 1)
tax.tab <- read.csv(isme.ectos.tax)
fungal.traits <- fungal_traits()
trait.tab <- read.csv(isme.traits)

# 1 add exploration type data to subset of tax.tab column ---- 

#Add exploraiton type data to the OTU table
otu.tax <- data.frame(Label = colnames(otu.tab))
otu.tax$Genus <- tax.tab$Genus[match(otu.tax$Label, tax.tab$Label)]
otu.tax$Species <- tax.tab$Species[match(otu.tax$Label, tax.tab$Label)]
otu.tax$Family <- tax.tab$Family[match(otu.tax$Label, tax.tab$Label)]
otu.tax$SH <- tax.tab$Taxonomy[match(otu.tax$Label, tax.tab$Label)]
otu.tax$Exploration_type <- trait.tab$Ectomycorrhiza_exploration_type_template[match(otu.tax$Genus, trait.tab$GENUS)]
#Now add exploration types from updated database
otu.tax$FT.new.exploration_type <- fungal.traits$em_expl[match(otu.tax$Genus, fungal.traits$Genus)]
otu.tax$FT.new.exploration_type.2 <- fungal.traits$em_text[match(otu.tax$Genus, fungal.traits$Genus)]

otu.tax$FT.new.exploration_type <- gsub("SD", "short-distance", otu.tax$FT.new.exploration_type)
otu.tax$FT.new.exploration_type <- gsub("MD", "medium-distance", otu.tax$FT.new.exploration_type)
otu.tax$FT.new.exploration_type <- gsub("LD", "long-distance", otu.tax$FT.new.exploration_type)
otu.tax$FT.new.exploration_type <- gsub("C", "contact", otu.tax$FT.new.exploration_type)
otu.tax$FT.new.exploration_type <- ifelse(!is.na(otu.tax$FT.new.exploration_type.2), paste0(otu.tax$FT.new.exploration_type,"_",otu.tax$FT.new.exploration_type.2),"")
otu.tax$FT.new.exploration_type <- tolower(otu.tax$FT.new.exploration_type)
otu.tax$FT.new.exploration_type <- ifelse(is.na(otu.tax$Exploration_type), otu.tax$FT.new.exploration_type, otu.tax$Exploration_type)
otu.tax$FT.new.exploration_type.2 <- NULL
otu.tax$Exploration_type <- NULL


#Now conduct co-occurrence analysis on the OTU-table

#Remove any OTUs found in fewer than 10% of the plots as that would be enough to do a regression (n = 14)
otu.tab <- data.frame(t(otu.tab))
otu.tab2 <- otu.tab[rowSums(otu.tab == 0) <= (0.9*length(colnames(otu.tab))), ]

#Now split the needle and broadleaf communities out
beech <- otu.tab2 %>% dplyr:: select(starts_with("BEECH"))
oak <- otu.tab2 %>% dplyr:: select(starts_with("OAK"))
pine <- otu.tab2 %>% dplyr:: select(starts_with("PINE"))
spruce <- otu.tab2 %>% dplyr:: select(starts_with("SPRUCE"))
broad <- cbind(beech, oak)
needle <- cbind(pine, spruce)

#Make presence absence matrix
broad[broad>0] <-1
needle[needle>0] <-1

#Now do the network analysis
beech.cooccur <- cooccur(broad, type = "spp_site", thresh = TRUE, spp_names = TRUE,
        site_mask = NULL, only_effects = FALSE,
        eff_standard = TRUE, eff_matrix = FALSE)

needle.cooccur <- cooccur(needle, type = "spp_site", thresh = TRUE, spp_names = TRUE,
                          site_mask = NULL, only_effects = FALSE,
                          eff_standard = TRUE, eff_matrix = FALSE)

# Grab the table of results
bp <- plot(beech.cooccur)
bp.data <- bp$data
bp.data$explore.1 <- otu.tax$FT.new.exploration_type[match(bp.data$X1, otu.tax$Label)]
bp.data$explore.2 <- otu.tax$FT.new.exploration_type[match(bp.data$X2, otu.tax$Label)]
bp.data$tax.1 <- otu.tax$Species[match(bp.data$X1, otu.tax$Label)]
bp.data$tax.2 <- otu.tax$Species[match(bp.data$X2, otu.tax$Label)]

#Make a network plot --- reduced data without random co-occurrences or unknown ETs --- 
bp.data.2 <- bp.data[!bp.data$value == 0, ]
bp.data.2$explore.1 <- ifelse(bp.data.2$explore.1 == "", "Unknown", bp.data.2$explore.1)
bp.data.2$explore.2 <- ifelse(bp.data.2$explore.2 == "", "Unknown", bp.data.2$explore.2)
bp.data.2 <- bp.data.2[!bp.data.2$explore.1 == "Unknown", ]
bp.data.2 <- bp.data.2[!bp.data.2$explore.2 == "Unknown", ]

# Convert to graph object
graph <- graph_from_data_frame(bp.data.2, directed = FALSE)

# Merge trait data into graph node attributes
V(graph)$Trait <- otu.tax$FT.new.exploration_type[match(V(graph)$name, otu.tax$Label)]
V(graph)$Tax <- otu.tax$Species[match(V(graph)$name, otu.tax$Label)]

# Define trait-based colors
trait_colors <- c("contact" = "aquamarine4", 
                  "long-distance" = "coral2", 
              #    "medium-distance_fringe" = "darkslateblue",
                  "medium-distance_smooth" = "darkorchid", 
                  "short-distance_coarse" = "darkolivegreen2", 
                  "short-distance_delicate" = "cadetblue1")

#Now plot using ggraph
broad.graph <- ggraph(graph, layout = "fr") + 
  geom_edge_link(aes(color = factor(value)), width = 1) +  
  geom_node_point(aes(color = Trait), size = 6, show.legend = FALSE) +  # Node color based on trait
  # geom_node_text(aes(label = Tax), repel = TRUE, size = 5) + 
  scale_edge_color_manual(values = c("-1" = "grey", "0" = "gray", "1" = "black"),
                          name = "Cooccurrence") +
  scale_color_manual(values = trait_colors, name = "Trait") +  # Color nodes by trait
  theme_void()

# Grab the table of results
nl <- plot(needle.cooccur)
nl.data <- nl$data
nl.data$explore.1 <- otu.tax$FT.new.exploration_type[match(nl.data$X1, otu.tax$Label)]
nl.data$explore.2 <- otu.tax$FT.new.exploration_type[match(nl.data$X2, otu.tax$Label)]
nl.data$tax.1 <- otu.tax$Species[match(nl.data$X1, otu.tax$Label)]
nl.data$tax.2 <- otu.tax$Species[match(nl.data$X2, otu.tax$Label)]

#Make a network plot --- reduced data without random co-occurrences or unknown ETs --- 
nl.data.2 <- nl.data[!nl.data$value == 0, ]
nl.data.2$explore.1 <- ifelse(nl.data.2$explore.1 == "", "Unknown", nl.data.2$explore.1)
nl.data.2$explore.2 <- ifelse(nl.data.2$explore.2 == "", "Unknown", nl.data.2$explore.2)
nl.data.2 <- nl.data.2[!nl.data.2$explore.1 == "Unknown", ]
nl.data.2 <- nl.data.2[!nl.data.2$explore.2 == "Unknown", ]


# Count occurrences of each value within each group
nl.df_summary <- nl.data %>%
  group_by(explore.1, value) %>%
  summarise(count = n(), .groups = "drop")

data.frame(nl.df_summary)

# Count occurrences of each value within each group
nl.df_summary <- nl.data %>%
  group_by(explore.1, value) %>%
  summarise(count = n(), .groups = "drop")

nl.sum <- data.frame(nl.df_summary)
nl.sum$Tree.type <- rep("Needleleaf", length(nl.sum$explore.1))

# Count occurrences of each value within each group
bp.df_summary <- bp.data %>%
  group_by(explore.1, value) %>%
  summarise(count = n(), .groups = "drop")

bl.sum <- data.frame(bp.df_summary)
bl.sum$Tree.type <- rep("Broadleaf", length(bl.sum$explore.1))

sum.sum <- rbind(nl.sum, bl.sum)
sum.sum <- sum.sum[!sum.sum$explore.1 == "", ]
sum.sum$value <- gsub("-1", "Negative", sum.sum$value)
sum.sum$value <- gsub("1", "Positive", sum.sum$value)
sum.sum$value <- gsub("0", "Random", sum.sum$value)

#Remove random because we don't care
sum.sum <- sum.sum[!sum.sum$value == "Random",]

#Set axis order
sum.sum$explore.1 <- factor(sum.sum$explore.1, levels = c("contact", "short-distance_delicate", "short-distance_coarse",
                                                          "medium-distance_smooth", "medium-distance_fringe", "long-distance"))


cooccurrence.gg <- ggplot(sum.sum, aes(x = value, y = count, fill = explore.1))+
  geom_bar(stat = 'identity', position = "dodge", show.legend = FALSE)+
  theme_classic()+
  coord_flip()+
  labs(x = "Co-occurrence", y = "Number of edges")+
  facet_wrap(.~Tree.type)+
  theme(strip.text = element_blank())+
  scale_fill_manual(values = c("aquamarine4", "cadetblue1", "darkolivegreen2", "darkorchid", "darkslateblue", "coral2"))


# Convert to graph object
graph <- graph_from_data_frame(nl.data.2, directed = FALSE)

# Merge trait data into graph node attributes
V(graph)$Trait <- otu.tax$FT.new.exploration_type[match(V(graph)$name, otu.tax$Label)]
V(graph)$Tax <- otu.tax$Species[match(V(graph)$name, otu.tax$Label)]

# Define trait-based colors
trait_colors <- c("contact" = "aquamarine4", 
                  "long-distance" = "coral2", 
                  "medium-distance_fringe" = "darkslateblue",
                  "medium-distance_smooth" = "darkorchid", 
                  "short-distance_coarse" = "darkolivegreen2", 
                  "short-distance_delicate" = "cadetblue1")

#Now plot using ggraph
pine.graph <- ggraph(graph, layout = "fr") + 
  geom_edge_link(aes(color = factor(value)), width = 1) +  
  geom_node_point(aes(color = Trait), size = 6, show.legend = FALSE) +  # Node color based on trait
 # geom_node_text(aes(label = Tax), repel = TRUE, size = 5) + 
  scale_edge_color_manual(values = c("-1" = "grey", "0" = "gray", "1" = "black"),
                          name = "Cooccurrence") +
    scale_color_manual(values = trait_colors, name = "Trait") +  # Color nodes by trait
  theme_void()

#Plot them together
plot_grid(broad.graph, pine.graph)


#########Now try to see if we can add some brief taxonomic labels to each hub


#################################################################################
################Check for differences btw. tree type in comm. comp############### --- 
#################################################################################

otu.tab$Exploration <- otu.tax$FT.new.exploration_type[match(row.names(otu.tab), otu.tax$Label)]
exp.comm.tabs <- split(otu.tab, otu.tab$Exploration)

#Contact type
exp.comm.tabs$contact$Exploration <- NULL
exp.comm.tabs$contact <- exp.comm.tabs$contact[!colSums(exp.comm.tabs$contact) == 0]
contact.envt <- data.frame(Plot = colnames(exp.comm.tabs$contact))
contact.envt.2 <- cSplit(contact.envt, "Plot", sep = "_")
contact.envt$Tree <- contact.envt.2$Plot_1
contact.envt$Tree_type <- ifelse(contact.envt$Tree %in% c("OAK", "BEECH"), "Broadleaf", "Needleleaf")
contact.type.results <- adonis2(vegdist(data.frame(t(exp.comm.tabs$contact))) ~ contact.envt$Tree_type) #Significant!

#SD-D type
exp.comm.tabs$`short-distance_delicate`$Exploration <- NULL
exp.comm.tabs$`short-distance_delicate` <- exp.comm.tabs$`short-distance_delicate`[!colSums(exp.comm.tabs$`short-distance_delicate`) == 0]
sdd.envt <- data.frame(Plot = colnames(exp.comm.tabs$`short-distance_delicate`))
sdd.envt.2 <- cSplit(sdd.envt, "Plot", sep = "_")
sdd.envt$Tree <- sdd.envt.2$Plot_1
sdd.envt$Tree_type <- ifelse(sdd.envt$Tree %in% c("OAK", "BEECH"), "Broadleaf", "Needleleaf")
sdd.type.results <- adonis2(vegdist(data.frame(t(exp.comm.tabs$`short-distance_delicate`))) ~ sdd.envt$Tree_type) #Significant!

#SD-C type
exp.comm.tabs$`short-distance_coarse`$Exploration <- NULL
exp.comm.tabs$`short-distance_coarse` <- exp.comm.tabs$`short-distance_coarse`[!colSums(exp.comm.tabs$`short-distance_coarse`) == 0]
sdc.envt <- data.frame(Plot = colnames(exp.comm.tabs$`short-distance_coarse`))
sdc.envt.2 <- cSplit(sdc.envt, "Plot", sep = "_")
sdc.envt$Tree <- sdc.envt.2$Plot_1
sdc.envt$Tree_type <- ifelse(sdc.envt$Tree %in% c("OAK", "BEECH"), "Broadleaf", "Needleleaf")
sdc.type.results <- adonis2(vegdist(data.frame(t(exp.comm.tabs$`short-distance_coarse`))) ~ sdc.envt$Tree_type) #Significant!

#MD-Smooth type
exp.comm.tabs$`medium-distance_smooth`$Exploration <- NULL
exp.comm.tabs$`medium-distance_smooth` <- exp.comm.tabs$`medium-distance_smooth`[!colSums(exp.comm.tabs$`medium-distance_smooth`) == 0]
mds.envt <- data.frame(Plot = colnames(exp.comm.tabs$`medium-distance_smooth`))
mds.envt.2 <- cSplit(mds.envt, "Plot", sep = "_")
mds.envt$Tree <- mds.envt.2$Plot_1
mds.envt$Tree_type <- ifelse(mds.envt$Tree %in% c("OAK", "BEECH"), "Broadleaf", "Needleleaf")
mds.type.results <- adonis2(vegdist(data.frame(t(exp.comm.tabs$`medium-distance_smooth`))) ~ mds.envt$Tree_type) #Significant!

#MD-Fringe type
exp.comm.tabs$`medium-distance_fringe`$Exploration <- NULL
exp.comm.tabs$`medium-distance_fringe` <- exp.comm.tabs$`medium-distance_fringe`[!colSums(exp.comm.tabs$`medium-distance_fringe`) == 0]
mdf.envt <- data.frame(Plot = colnames(exp.comm.tabs$`medium-distance_fringe`))
mdf.envt.2 <- cSplit(mdf.envt, "Plot", sep = "_")
mdf.envt$Tree <- mdf.envt.2$Plot_1
mdf.envt$Tree_type <- ifelse(mdf.envt$Tree %in% c("OAK", "BEECH"), "Broadleaf", "Needleleaf")
mdf.type.results <- adonis2(vegdist(data.frame(t(exp.comm.tabs$`medium-distance_fringe`))) ~ mdf.envt$Tree_type) #Significant!

#Long distance type
exp.comm.tabs$`long-distance`$Exploration <- NULL
exp.comm.tabs$`long-distance` <- exp.comm.tabs$`long-distance`[!colSums(exp.comm.tabs$`long-distance`) == 0]
ld.envt <- data.frame(Plot = colnames(exp.comm.tabs$`long-distance`))
ld.envt.2 <- cSplit(ld.envt, "Plot", sep = "_")
ld.envt$Tree <- ld.envt.2$Plot_1
ld.envt$Tree_type <- ifelse(ld.envt$Tree %in% c("OAK", "BEECH"), "Broadleaf", "Needleleaf")
ld.type.results <- adonis2(vegdist(data.frame(t(exp.comm.tabs$`long-distance`))) ~ ld.envt$Tree_type) #Significant!

#Communities are different across the board, now make one visualization to capture it all
ad.coef <- data.frame(R2 = c(contact.type.results$R2[1],
sdd.type.results$R2[1],
sdc.type.results$R2[1],
mds.type.results$R2[1],
mdf.type.results$R2[1],
ld.type.results$R2[1]),
Group = c("C", "SD-D", "SD-C", "MD-S", "MD-F", "LD"))

#Set axis order
ad.coef$Group <- factor(ad.coef$Group, levels = c("C", "SD-D", "SD-C", "MD-S", "MD-F", "LD"))

coeff <- ggplot(ad.coef, aes(x = Group, y = round(R2, digits = 2), fill = Group)) + geom_bar(stat = 'identity', show.legend = FALSE)+
         theme_classic()+
         labs(x = "", y = "Coefficient of determination")+
         scale_fill_manual(values = c("aquamarine4", "cadetblue1", "darkolivegreen2", "darkorchid", "darkslateblue", "coral2"))


money.fig <- plot_grid(coeff, cooccurrence.gg, broad.graph, pine.graph, ncol = 2)

