# Model the relative abundances of exploration types ----

#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

require(dplyr); require(tidyr); require(data.table); require(splitstackshape); require(pls)
require(reshape2); require(cowplot); require(ggplot2); require(chillR)

icp.dat <- read.csv(icp.data.envt)
isme.explorers.2 <- readRDS(isme.explore.2.new.fungal.traits)
isme.explorers <- readRDS(isme.explore)
soil.explorers <- readRDS(soil.explore)
soil.exploreres.2 <- readRDS(soil.explore.2.new.fungal.traits)


#Combine the env't and species matrices
isme.explorers.w.envt <- merge(isme.explorers, icp.dat, by = "country_plot")

#Fix stand age variable
isme.explorers.w.envt$Stand.age <- as.numeric(as.character(gsub(".9", ".0", isme.explorers.w.envt$Stand.age)))

#Make a new variable that is the foliar p:n ratio
isme.explorers.w.envt$p.n <- isme.explorers.w.envt$p/isme.explorers.w.envt$n

#Now let's build the models to predict short-distance coarse relative abundances ----

#fit short distance-coarse model
sd.c <- plsr(short.distance_coarse ~ log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + M01.pH + log(mg_C_ha_yr)*Tree_type + lat+ N_dep_2019 + Stand.age +
               MAT + MAP + clay_0.5cm_mean, 
             data=isme.explorers.w.envt, 
             scale=TRUE, validation="CV", method = "oscorespls")

summary(sd.c) 

#Visualize cross-validation plots
validationplot(sd.c, val.type="MSEP")
hist(sd.c$residuals)
qqnorm(sd.c$residuals) # nice!

#look at variable importance in the projection scores (ViP)
VIP(sd.c)

# What if we remove the least informative variables ViP < 0.8 on Comp 1-3?  
# log(n),log(Mineral.Nitrogen.Stock), pH, tree growth, N_dep_2019, Map, clay_0.5cm_mean, log(mg_C_ha_yr)*Tree_type
sd.c.2 <- plsr(short.distance_coarse ~ log(p.n)*Tree_type + lat + Stand.age + MAT,
               data=isme.explorers.w.envt, 
               scale=TRUE, validation="CV", method = "oscorespls")

summary(sd.c.2) 
summary(sd.c)

#Visualize cross-validation plots
validationplot(sd.c.2, val.type="MSEP")
hist(sd.c.2$residuals)
qqnorm(sd.c.2$residuals)

#look at variable importance in the projection scores (ViP)
VIP(sd.c.2)
plot(sd.c.2, ncomp = 3, asp = 1, line = TRUE) #A bit skewed but not super bad

#Now try to predict new observations
sd.c.2.predict <- predict(sd.c.2, ncomp = 3, newdata = isme.explorers.w.envt[1:50,], na.action = "na.omit")
sd.c.2.subset <- (isme.explorers.w.envt[rownames(isme.explorers.w.envt) %in% row.names(sd.c.2.predict), ])

#Now calculate the root mean sqare error (RMSE) - the average deviation between the predicted rel. abund. and observed
sqrt(mean((sd.c.2.predict - sd.c.2.subset$short.distance_coarse)^2))

#Now plot the VIF scores for Comps 1, 2, and 3
sd.c.2.vip <- data.frame(VIP(sd.c.2))
sd.c.2.vip.df <- data.frame(Comp = c(rep(c("Comp1","Comp2", "Comp3"), 6)),
                            Factor = c(rep("Tree type", 3),
                                       rep("Foliar P:N", 3), 
                                       rep("Latitude", 3),
                                       rep("Stand age", 3),
                                       rep("Mean annual temperature", 3), 
                                       rep("Foliar P:N x Tree type", 3)),
                            VIP = c(sd.c.2.vip$Tree_typeconifers[1:3],
                                    sd.c.2.vip$log.p.n.[1:3],
                                    sd.c.2.vip$lat[1:3],
                                    sd.c.2.vip$Stand.age[1:3],
                                    sd.c.2.vip$MAT[1:3],
                                    sd.c.2.vip$log.p.n..Tree_typeconifers[1:3]))

sd.c.vip.plot <- ggplot(sd.c.2.vip.df, aes(x = reorder(Factor,VIP), y = VIP))+
  geom_bar(stat = 'identity', show.legend = FALSE)+
  theme_classic()+
  coord_flip()+
  labs(x = "", y = "ViP")+
  scale_fill_manual(values = c("orange", "blue"))  


# DON'T RUN THIS UNLESS MAKING THE PLOTS FOR A PANEL AND NEEDING TO GO TO THE NEXT SCRIPT!!!!!
# For plotting purposes only since making the plots from multiple scripts:
# rm(list=setdiff(ls(), c("cm.f.vip.plot", "sd.d.vip.plot", "sd.c.vip.plot", 
#                        "md.s.vip.plot", "md.f.vip.plot", "lm.vip.plot")))



# Get stats!----

#Now split these out by tree type to isolate the conifer effects
isme.explorers.w.envt.sp <- split(isme.explorers.w.envt, isme.explorers.w.envt$Tree_type)

#this function will remove infinite values
inf2NA <- function(x) { x[is.infinite(x)] <- NA; x }

# check tree type comparison
kruskal.test(isme.explorers.w.envt$short.distance_coarse, isme.explorers.w.envt$Tree_type)

# broad:conifer ratio = 1.555693
mean(isme.explorers.w.envt.sp$broadleaves$short.distance_coarse)/mean(isme.explorers.w.envt.sp$conifers$short.distance_coarse)


# short.distance_coarse ~ log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + lat + Stand.age + MAT + MAP + clay_0.5cm_mean

# Broadleaves
cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$short.distance_coarse*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$p.n)), use="pairwise.complete.obs") # cor 0.0967006 (n/s)


cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$short.distance_coarse*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$lat)), use="pairwise.complete.obs") # cor 0.06992341 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$short.distance_coarse*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$Stand.age)), use="pairwise.complete.obs") # cor -0.3659615 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$short.distance_coarse*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$MAT)), use="pairwise.complete.obs") # cor -0.1098521 (n/s)


# Conifers
cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$short.distance_coarse*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$p.n)), use="pairwise.complete.obs") # cor 0.0005622565 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$short.distance_coarse*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$lat)), use="pairwise.complete.obs") # cor -0.03282957 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$short.distance_coarse*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$N_dep_2019)), use="pairwise.complete.obs") # cor 0.05796863 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$short.distance_coarse*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$MAT)), use="pairwise.complete.obs") # cor -0.01445517 (n/s)


