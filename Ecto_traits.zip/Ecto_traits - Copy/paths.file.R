#Make Paths file

#path to where all data is stored - for example...
#root.path <- "/Users/marka.anthony/Documents/R_projects/Ecto_traits/Ecto_traits/data_storage/" 
#root.path <- "F:/Postdoc_Vienna/V002_EctoTraits/Ecto_traits/data_storage/"           

#Now make the sub-directories for raw data-----
raw.path<- paste0(root.path,"raw_data/")

#Already bioinformatics run fungal data, ICP Forests data
isme.ectos <- paste0(raw.path, "rare.OTU.csv")
isme.ectos.tax <- paste0(raw.path, "Taxon_info.csv")
isme.traits <- paste0(raw.path, "Fungal_traits_1_2_dec_2020.csv")
isme.envt <- paste0(raw.path, "SIETSE_mapping3.csv")
icpf.fungi<- paste0(raw.path,"feature-table.tsv")
icpf.envt.mat<- paste0(raw.path,"Envt_matrix.csv")
icpf.funguild.mat  <- paste0(raw.path, "Funguild.feed.taxa.guilds.txt")
icpf.tax <- paste0(raw.path, "sh_taxonomy_qiime_ver8_dynamic_10.05.2021.txt")
icp.data.envt <- paste0(raw.path, "icp.envt.data.csv")
cazy.path <- paste0(raw.path, "CAZymes.csv")
pfams.path <- paste0(raw.path, "PFAMES.csv")
info.path <- paste0(raw.path, "Mycocosm_names_meta_data.csv")
myco.use <- paste0(raw.path, "Genome_use.csv")

#Now make the sub-directories for data products----
product.path<- paste0(root.path,"data_products/")

#Processed data files
isme.explore <- paste0(product.path, "isme.explore.csv")
isme.explore.2.new.fungal.traits <- paste0(product.path, "isme.explore.2.new.fungal.traits.csv")
soil.explore <- paste0(product.path, "soil.explore.csv")
soil.explore.2.new.fungal.traits <- paste0(product.path, "soil.explore.2.new.fungal.traits.csv")
saprotroph.save <- paste0(product.path, "guild.summary.csv")
pfam.indicators.save.string <- paste0(product.path, "pfma.indicators.csv")

# For heatmaps - Pearson's correlations based on selected VIPs
broadleaf.heatmap <- paste0(raw.path, "Heatmap_broadleaf.csv")
needleleaf.heatmap <- paste0(raw.path, "Heatmap_needleleaf.csv")
