#Model the relative abundances of exploration types ----

#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

require(dplyr)
require(tidyr)
require(data.table)
require(splitstackshape)
require(pls)
require(reshape2)
require(cowplot)

icp.dat <- read.csv(icp.data.envt)
isme.explorers.2 <- readRDS(isme.explore.2.new.fungal.traits)
isme.explorers <- readRDS(isme.explore)
soil.explorers <- readRDS(soil.explore)
soil.exploreres.2 <- readRDS(soil.explore.2.new.fungal.traits)

#Combine the env't and species matrices
soil.exploreres.with.envt <- merge(soil.explorers, icp.dat, by = "country_plot")
soil.exploreres.with.envt$Stand.age <- gsub(".9", ".0", soil.exploreres.with.envt$Stand.age)
soil.exploreres.with.envt$Stand.age <- as.numeric(as.character(soil.exploreres.with.envt$Stand.age))

#Split by horizon
soil.exploreres.with.envt.split <- split(soil.exploreres.with.envt, soil.exploreres.with.envt$Horizon)
soil.exploreres.with.envt.split$Org$pn <- soil.exploreres.with.envt.split$Org$p/soil.exploreres.with.envt.split$Org$n
#Now let's build the models to predict medium-distance fringe relative abundances

#fit med. distance-fringe model
md.f <- plsr(log10(1+medium.distance_fringe) ~ log(n)*Tree_type + log(pn)*Tree_type + OFH.Nitrogen.Stock + OFH.pH + log(mg_C_ha_yr)*Tree_type + lat +
               N_dep_2019 + Stand.age + MAT + MAP + clay_0.5cm_mean, data = soil.exploreres.with.envt.split$Org, 
               scale=TRUE, validation="CV", method = "oscorespls")

summary(md.f) 

#Visualize cross-validation plots
validationplot(md.f, val.type="MSEP")
hist(md.f$residuals)
qqnorm(md.f$residuals)

#look at variable importance in the projection scores (ViP)
VIP(md.f)

#What if we remove the least informative variables? -  OFH.pH, MAT, MAP, clay, 
md.f.2 <- plsr(log10(1+medium.distance_fringe) ~ log(n)*Tree_type + log(pn)*Tree_type + OFH.Nitrogen.Stock + log(mg_C_ha_yr)*Tree_type + lat +
                 N_dep_2019 + Stand.age, data = soil.exploreres.with.envt.split$Org, 
                 scale=TRUE, validation="CV", method = "oscorespls")

summary(md.f.2) 
summary(md.f)

#Visualize cross-validation plots
validationplot(md.f.2, val.type="MSEP")
hist(md.f.2$residuals)
qqnorm(md.f.2$residuals)

#look at variable importance in the projection scores (ViP)
VIP(md.f.2)
plot(md.f.2, ncomp = 2, asp = 1, line = TRUE) #Looks quite good!

#Now plot the VIF scores for Comp1 and 2
md.f.2.vip <- data.frame(VIP(md.f.2))
md.f.2.vip.df <- data.frame(Comp = c(rep(c("Comp1","Comp2"), 11)),
                            Factor = c(rep("Foliar N", 2),rep("Tree type", 2), rep("Foliar P:N", 2), rep("Soil N", 2), rep("Tree growth", 2), 
                                       rep("Latitude", 2), rep("N dep.", 2), rep("Stand age", 2), rep("Foliar N x tree type", 2), rep("Foliar P:N x tree type", 2),
                                       rep("Tree growth x tree type", 2)),
                            VIP = c(md.f.2.vip$log.n.[1:2],md.f.2.vip$Tree_typeconifers[1:2],md.f.2.vip$log.pn.[1:2],md.f.2.vip$OFH.Nitrogen.Stock[1:2],md.f.2.vip$log.mg_C_ha_yr.[1:2],
                                    md.f.2.vip$lat[1:2],md.f.2.vip$N_dep_2019[1:2], md.f.2.vip$Stand.age[1:2], md.f.2.vip$log.n..Tree_typeconifers[1:2],md.f.2.vip$Tree_typeconifers.log.pn.[1:2],
                                    md.f.2.vip$Tree_typeconifers.log.mg_C_ha_yr.[1:2]))

md.f.vip.plot <- ggplot(md.f.2.vip.df, aes(x = reorder(Factor,VIP), y = VIP))+
  geom_bar(stat = 'identity', show.legend = FALSE)+
  theme_classic()+
  coord_flip()+
  labs(x = "", y = "ViP")+
  scale_fill_manual(values = c("orange", "blue"))  

#Some of the interactions were critical so we need to examine conifers and broadleaves seperately
sexp.sp <- split(soil.exploreres.with.envt.split$Org, soil.exploreres.with.envt.split$Org$Tree_type)


#And now visualize the main effects as scatterplots
age <- ggplot(soil.exploreres.with.envt.split$Org, aes(x = as.factor(Stand.age), y = log10(medium.distance_fringe)))+
  geom_boxplot(aes(color = Tree_type), show.legend = FALSE)+
#  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Medium distance-fringe log(%)", 
                         x = "Stand age")+
  scale_color_manual(values = c("purple", "green")) 




#Get statistics
#this function will remove infinite values
inf2NA <- function(x) { x[is.infinite(x)] <- NA; x }

#Get stats!
cor.test(inf2NA(log(sexp.sp$conifers$mg_C_ha_yr)), inf2NA(log10(sexp.sp$conifers$medium.distance_fringe)),
         use="pairwise.complete.obs")

growth <- ggplot(soil.exploreres.with.envt.split$Org, aes(y = log(OFH.Nitrogen.Stock), x = log10(medium.distance_fringe)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         x = "Medium distance-fringe log(%)", 
                         y = expression(paste("Tree growth scaled(t C h", a^{-1}," y", r^{-1}, ")")), fill = "")+
   scale_color_manual(values = c("purple", "green"))+
  #scale_color_manual(values = c("green"))+
  theme(aspect.ratio = 1)

N_dep <- ggplot(soil.exploreres.with.envt.split$Org, aes(x = scale(N_dep_2019), y = log10(medium.distance_fringe)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Medium distance-fringe (%)", 
                         x = expression(paste("N deposition scale(mg N ", m^{2}," ", y^{-1},")")))+
  scale_color_manual(values = c("purple", "green"))  

Lat <- ggplot(soil.exploreres.with.envt.split$Org, aes(x = lat, y = log10(medium.distance_fringe)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Medium distance-fringe (%)", 
                         x = "scale(Latitude)")+
  scale_color_manual(values = c("purple", "green"))

fol.pn.1 <- ggplot(soil.exploreres.with.envt.split$Org, aes(y = scale(log(pn)), x = log10(medium.distance_fringe)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Medium distance-fringe (%)", 
                         x = expression(paste("Foliar P:N ratio scale(m", g^{-1},")")))+
 # scale_color_manual(values = c("green"))
  scale_color_manual(values = c("purple", "green"))
#+ facet_wrap(.~Tree_type, scales = "free")



#Get stats
cor.test(inf2NA(log(sexp.sp$conifers$pn)), inf2NA(log10(sexp.sp$conifers$medium.distance_fringe)),
         use="pairwise.complete.obs")

fol.pn.2 <- ggplot(sexp.sp$conifers, aes(y = log(pn), x = log10(medium.distance_fringe)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         x = "Medium distance-fringe (%)", 
                         y = expression(paste("Foliar P:N ratio")))+
   scale_color_manual(values = c("green"))+
  theme(aspect.ratio = 1)


N.stock <- ggplot(soil.exploreres.with.envt.split$Org, aes(y = log(OFH.Nitrogen.Stock), x = log10(medium.distance_fringe)))+
  geom_point(show.legend = FALSE, color = "green")+
#  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         x = "Medium distance-fringe log(%)", 
                         y = expression(paste("Soil N stock log(t N h", a^{-1},")")), fill = "")+
 # scale_color_manual(values = c("purple", "green"))+
  scale_color_manual(values = c("green"))+
  theme(aspect.ratio = 1)

fol.n <- ggplot(sexp.sp$conifers, aes(x = scale(log(n)), y = log10(medium.distance_fringe)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Medium distance-fringe (%)", 
                         x = expression(paste("Foliar N levels scale(m", g^{-1},")")))+
  scale_color_manual(values = c("purple", "green"))+ facet_wrap(.~Tree_type, scales = "free")


plot_grid(fol.pn.2, N.stock, scales = "vh")


#Make a figure for ICOM



#Bring it all together now
row.1 <- plot_grid(md.f.vip.plot, Lat, N_dep, ncol = 3)
row.2 <- plot_grid(age, fol.p, ncol = 2)
med.results <- plot_grid(row.1, row.2, ncol = 1)



