
# similarity dendogram for correlations

source('paths.file.r')

broad <- read.csv(broadleaf.heatmap)
row.names(broad) <- broad$Code.broadleaf
broad$Code.broadleaf <- NULL

needle <- read.csv(needleleaf.heatmap)
row.names(needle) <- needle$Code.needleleaf
needle$Code.needleleaf <- NULL

library(vegan)

# make distance distance table
bray.otu.broad <- vegdist(t(broad), method = "euclidean")

bray.otu.needle <- vegdist(t(needle), method = "euclidean")


#hclust
clust.broad <- hclust(bray.otu.broad, method = "ward.D")
  
clust.needle <- hclust(bray.otu.needle, method = "ward.D")

# similarity
library(ape)
plot(as.phylo(clust.broad))

plot(as.phylo(clust.needle))



