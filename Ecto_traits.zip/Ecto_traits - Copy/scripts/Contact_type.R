#Model the relative abundances of exploration types ----

#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

require(dplyr); require(tidyr); require(data.table); require(splitstackshape); require(pls)
require(reshape2); require(cowplot); require(ggplot2); require(chillR)

icp.dat <- read.csv(icp.data.envt)
isme.explorers.2 <- readRDS(isme.explore.2.new.fungal.traits)
isme.explorers <- readRDS(isme.explore)
soil.explorers <- readRDS(soil.explore)
soil.exploreres.2 <- readRDS(soil.explore.2.new.fungal.traits)

#Combine the env't and species matrices
isme.explorers.w.envt <- merge(isme.explorers, icp.dat, by = "country_plot")

#Fix stand age variable
isme.explorers.w.envt$Stand.age <- as.numeric(as.character(gsub(".9", ".0", isme.explorers.w.envt$Stand.age)))

#Make a new variable that is the foliar p:n ratio
isme.explorers.w.envt$p.n <- isme.explorers.w.envt$p/isme.explorers.w.envt$n

#Now let's build the models to predict contact relative abundances ----

#fit contact model
c.m <- plsr(contact ~ log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + M01.pH + log(mg_C_ha_yr)*Tree_type + lat+ N_dep_2019 + Stand.age +
            MAT + MAP + clay_0.5cm_mean, 
            data=isme.explorers.w.envt, 
            scale=TRUE, validation="CV", method = "oscorespls")

#Visualize cross-validation plots
validationplot(c.m, val.type="MSEP")
hist(c.m$residuals)
qqnorm(c.m$residuals)

#look at variable importance in the projection scores (ViP)
VIP(c.m)

# What if we remove the least informative variables ViP < 0.8 on Comp 1-3? 
# tree type, log(p:n), N stocks, lat, stand age, MAT, MAP, tree type x log(n), tree type x log(p:n)
cm.2 <- plsr(contact ~ M01.pH + log(mg_C_ha_yr)+ N_dep_2019 + clay_0.5cm_mean, 
             data=isme.explorers.w.envt, 
             scale=TRUE, validation="CV", method = "oscorespls")

summary(cm.2) 
summary(c.m)

#Visualize cross-validation plots
validationplot(cm.2, val.type="MSEP")
hist(cm.2$residuals)
qqnorm(cm.2$residuals)

#look at variable importance in the projection scores (ViP)
VIP(cm.2)
plot(cm.2, ncomp = 3, asp = 1, line = TRUE) #Looks quite bad!

#Now try to predict new observations
cm.2.predict <- predict(cm.2, ncomp = 3, newdata = isme.explorers.w.envt[1:50,], na.action = "na.omit")
cm.2.subset <- (isme.explorers.w.envt[rownames(isme.explorers.w.envt) %in% row.names(cm.2.predict), ])

#Now calculate the root mean sqare error (RMSE) - the average deviation between the predicted rel. abund. and observed
sqrt(mean((cm.2.predict - cm.2.subset$contact)^2))

#Now plot the VIF scores for Comps 1, 2, and 3
cm.2.2.vip <- data.frame(VIP(cm.2))
cm.f.2.vip.df <- data.frame(Comp = c(rep(c("Comp1", "Comp2", "Comp3"), 4)),
                            Factor = c(rep("Soil pH", 3),  
                                       rep("Forest productivity", 3), 
                                       rep("N deposition", 3), 
                                       rep("Soil clay content", 3)), 
                            VIP = c(cm.2.2.vip$M01.pH[1:3], 
                                    cm.2.2.vip$log.mg_C_ha_yr.[1:3], 
                                    cm.2.2.vip$N_dep_2019[1:3], 
                                    cm.2.2.vip$clay_0.5cm_mean[1:3]))

cm.f.vip.plot <- ggplot(cm.f.2.vip.df, aes(x = reorder(Factor,VIP), y = VIP))+
  geom_bar(stat = 'identity', show.legend = FALSE)+
  theme_classic()+
  coord_flip()+
  labs(x = "", y = "")


# DON'T RUN THIS UNLESS MAKING THE PLOTS FOR A PANEL AND NEEDING TO GO TO THE NEXT SCRIPT!!!!!
# For plotting purposes only since making the plots from multiple scripts:
# rm(list=setdiff(ls(), c("cm.f.vip.plot", "sd.d.vip.plot", "sd.c.vip.plot", 
#                      "md.s.vip.plot", "md.f.vip.plot", "lm.vip.plot")))



# Get stats! ----

#Split the dataset now by tree type
isme.explorers.w.envt.sp <- split(isme.explorers.w.envt, isme.explorers.w.envt$Tree_type)

#this function will remove infinite values
inf2NA <- function(x) { x[is.infinite(x)] <- NA; x }

# check tree type comparison
kruskal.test(isme.explorers.w.envt$contact, isme.explorers.w.envt$Tree_type)

# broad:conifer ratio = 1.005558
mean(isme.explorers.w.envt.sp$broadleaves$contact)/mean(isme.explorers.w.envt.sp$conifers$contact)


# contact ~ M01.pH + log(mg_C_ha_yr)+ N_dep_2019 + clay_0.5cm_mean

# Broadleaves
cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$contact*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$M01.pH)), use="pairwise.complete.obs") # cor -0.5188995 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$contact*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$mg_C_ha_yr)), use="pairwise.complete.obs") # cor 0.2256741 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$contact*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$N_dep_2019)), use="pairwise.complete.obs") # cor 0.2074626 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$contact*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$clay_0.5cm_mean)), use="pairwise.complete.obs") # cor -0.3546349 (significant)

# Conifers
cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$contact*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$M01.pH)), use="pairwise.complete.obs") # cor -0.1461731 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$contact*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$mg_C_ha_yr)), use="pairwise.complete.obs") # cor 0.1640256 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$contact*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$N_dep_2019)), use="pairwise.complete.obs") # cor 0.2638101 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$contact*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$clay_0.5cm_mean)), use="pairwise.complete.obs") # cor 0.156821 (n/s)



#And now visualize the main effects as scatterplots ----
tree_type <- ggplot(isme.explorers.w.envt, aes(x = Tree_type, y = 100*contact))+
  geom_boxplot(aes(color = Tree_type), show.legend = FALSE)+
  theme_classic() + labs(color = "",
                         y = "Contact type (%)", 
                         x = "")+
  scale_color_manual(values = c("purple", "green"))+
  coord_flip()+
  theme(aspect.ratio = 1)

clay <- ggplot(isme.explorers.w.envt.sp$broadleaves, aes(x = scale(log(clay_0.5cm_mean)), y = log(100*contact)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Contact type log(%)", 
                         x = "Soil clay content scaled(%)")+
  scale_color_manual(values = c("purple", "green"))+
  theme(aspect.ratio = 1)

soil.pH <- ggplot(isme.explorers.w.envt.sp$broadleaves, aes(x = scale(log(M01.pH)), y = log(100*contact)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Contact type log(%)", 
                         x = "Soil pH (scaled)")+
  scale_color_manual(values = c("purple", "green"))+
  theme(aspect.ratio = 1)

Ndep <- ggplot(isme.explorers.w.envt.sp$broadleaves, aes(x = scale(log(N_dep_2019)), y = log(100*contact)))+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Contact type log(%)", 
                         x = expression(paste("N deposition scaled scaled(mg N ", m^{2}," ", y^{-1},")")))+
  scale_color_manual(values = c("purple", "green"))+
  theme(aspect.ratio = 1)

tree_growth <- ggplot(isme.explorers.w.envt, aes(x = log(mg_C_ha_yr), y = log(100*contact), color = Tree_type))+
  geom_point(show.legend = FALSE)+
  geom_smooth(method = 'lm', formula = y ~ x, color = "black")+
  theme_classic() + labs(color = "",
                         y = "Contact type log(%)", 
                         x = expression(paste("Tree growth scaled(t C h", a^{-1}," y", r^{-1}, ")")), fill = "")+
  scale_color_manual(values = c("purple", "green")) # +  facet_wrap(.~Tree_type, scales = "free")+
  theme(strip.background = element_blank(), strip.text = element_blank())+
  theme(aspect.ratio = 1)


#Bring it all together now
tog.row.1 <- plot_grid(tree_type, clay, ncol = 2)
tog.row.2 <- plot_grid(soil.pH, Ndep, ncol = 2)
tog.row.3 <- plot_grid(Ndep, tree_growth, ncol = 2)
contact.figure <- plot_grid(tog.row.1, tog.row.2, tog.row.3, ncol = 1)

#Now just the significant effects
contact.figure <- plot_grid(tog.row.1, tog.row.2, ncol = 1)



