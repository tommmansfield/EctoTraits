#Make datasets of fungal data ----

#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

require(dplyr)
require(tidyr)
require(fungaltraits)
require(data.table)
require(splitstackshape)
require(vegan)

#Set names of output files to save
isme.explore.save <- isme.explore
isme.explore.2.new.fungal.traits.save <- isme.explore.2.new.fungal.traits
soil.explore.save <- soil.explore
soil.explore.2.new.fungal.traits.save <- soil.explore.2.new.fungal.traits

#Upload the fungal data
otu.tab <- read.csv(isme.ectos, row.names = 1)
envt.tab <- read.csv(isme.envt, row.names = 1)
tax.tab <- read.csv(isme.ectos.tax)
trait.tab <- read.csv(isme.traits)
fungal.traits <- fungal_traits()
soil.tab <- as.data.frame(fread(icpf.fungi, sep = '\t'))
soil.envt.tab <- read.csv(icpf.envt.mat)
soil.funguild.tab <- fread(icpf.funguild.mat, sep = '\t')
soil.tax.tab <- read.csv(icpf.tax, sep = '\t', header = FALSE)
soil.tax.tab <- data.frame(cSplit(soil.tax.tab, 'V2', sep = ";", type.convert = FALSE))
icp.info <- readRDS(icp.dat)

#Compile all exploration types data

#. 1 add exploration type data to subset of tax.tab column

#First do this for the ISME 2022 data
otu.tax <- data.frame(Label = colnames(otu.tab))
otu.tax$Genus <- tax.tab$Genus[match(otu.tax$Label, tax.tab$Label)]
otu.tax$Species <- tax.tab$Species[match(otu.tax$Label, tax.tab$Label)]
otu.tax$Family <- tax.tab$Family[match(otu.tax$Label, tax.tab$Label)]
otu.tax$SH <- tax.tab$Taxonomy[match(otu.tax$Label, tax.tab$Label)]
otu.tax$Exploration_type <- trait.tab$Ectomycorrhiza_exploration_type_template[match(otu.tax$Genus, trait.tab$GENUS)]
#Now add exploration types from updated database
otu.tax$FT.new.exploration_type <- fungal.traits$em_expl[match(otu.tax$Genus, fungal.traits$Genus)]
otu.tax$FT.new.exploration_type.2 <- fungal.traits$em_text[match(otu.tax$Genus, fungal.traits$Genus)]

#Now do this for the ICPF Microbiome data
soil.otu.tax <- data.frame(OTU = soil.tab$`#OTU ID`)
soil.otu.tax$Genus <- soil.tax.tab$V2_6[match(soil.otu.tax$OTU, soil.tax.tab$V1)]
soil.otu.tax$Genus <- gsub("g__", "",soil.otu.tax$Genus)
soil.otu.tax$Species <- soil.tax.tab$V2_7[match(soil.otu.tax$OTU, soil.tax.tab$V1)]
soil.otu.tax$Family <- soil.tax.tab$V2_5[match(soil.otu.tax$OTU, soil.tax.tab$V1)]
soil.otu.tax$Exploration_type <- trait.tab$Ectomycorrhiza_exploration_type_template[match(soil.otu.tax$Genus, trait.tab$GENUS)]
#Now add exploration types from updated database
soil.otu.tax$FT.new.exploration_type <- fungal.traits$em_expl[match(soil.otu.tax$Genus, fungal.traits$Genus)]
soil.otu.tax$FT.new.exploration_type.2 <- fungal.traits$em_text[match(soil.otu.tax$Genus, fungal.traits$Genus)]

#. 2 clean up the soil species rel. abund. matrix
#ISME is already sorted/rarified, but we need to do this first for soil

########--------------------------------------------------------------------
##Non ICP samples to remove
otu.tab2 <- soil.tab
row.names(otu.tab2) <- otu.tab2$`#OTU ID`
otu.tab2$`#OTU ID` <- NULL
otu.tab2$S_364 <- NULL
otu.tab2$S_365<- NULL
otu.tab2$S_366<- NULL
otu.tab2$S_367<- NULL
otu.tab2$S_368<- NULL
otu.tab2$S_369<- NULL
otu.tab2$S_370<- NULL
otu.tab2$S_371<- NULL
otu.tab2$S_372<- NULL
otu.tab2$S_373<- NULL
otu.tab2$S_374<- NULL
otu.tab2$S_376<- NULL
otu.tab2$S_4<- NULL
otu.tab2$S_11<- NULL
otu.tab2$S_292<- NULL
otu.tab2$S_293<- NULL
otu.tab2$S_325<- NULL
otu.tab2$S_329<- NULL
otu.tab2$S_340<- NULL
otu.tab2$S_358<- NULL
otu.tab2$X2.S_29_2019<- NULL
otu.tab2$X2.S_41_2019<- NULL
otu.tab2$S_115_2019<- NULL
otu.tab2$X2.S_54_2019<- NULL
otu.tab2$X2.S_102_2019<- NULL
otu.tab2$X2.S_107_2019<- NULL
otu.tab2$X2.S_108_2019<- NULL
otu.tab2$X2.S_109_2019<- NULL
otu.tab2$X2.S_110_2019<- NULL
otu.tab2$X2.S_111_2019<- NULL
otu.tab2$X2.S_112_2019<- NULL
otu.tab2$S_15_2019<- NULL
otu.tab2$S_22_2019<- NULL
otu.tab2$S_29_2019<- NULL
otu.tab2$S_36_2019<- NULL
otu.tab2$S_46_2019<- NULL
otu.tab2$S_56_2019<- NULL
otu.tab2$S_71_2019<- NULL
otu.tab2$X2.S_57_2019<- NULL

#Now lets look at column sums
otu.tab2 <- data.frame(t(otu.tab2))

#Remove samples with <1000 sequences --  
high.depth.otu<- subset(otu.tab2, rowSums(otu.tab2) > 1000)

#We need to rarefy to the lowest sequencing depth
play <- rrarefy(as.matrix(high.depth.otu), (min(rowSums(high.depth.otu))-1))

#Make proportional
play<- data.frame(prop.table(as.matrix(high.depth.otu), 1))

#Remove OTUS without any values >0
play2<- play[, which(colSums(play) != 0)]
########--------------------------------------------------------------------

# 3. Compute relative abundance of exploration types now

#Now match each Genus level to an exploration type
taxon.info$form <- traits$Ectomycorrhiza_exploration_type_template[match(taxon.info$Genus, traits$GENUS)]

#Now add this column to the fungal community file
otu.tab.t <- data.frame(t(otu.tab))
otu.tab.t$form <- otu.tax$Exploration_type[match(row.names(otu.tab.t), otu.tax$Label)]
form.list<- otu.tab.t$form
otu.tab.t$form <- NULL
att1 <- aggregate(. ~  form.list, data= otu.tab.t, FUN = "sum")
row.names(att1) = att1$form.list
att1$form.list<- NULL
isme.soil.exploration.type <- data.frame(t(att1))
isme.soil.exploration.type$unknown <- isme.soil.exploration.type$V1
isme.soil.exploration.type$V1<- NULL 

#Now repeat for updated traits database
otu.tab.t <- data.frame(t(otu.tab))
otu.tax$FT.new.explore <- paste0(otu.tax$FT.new.exploration_type, "_", otu.tax$FT.new.exploration_type.2)
otu.tax$FT.new.explore <- gsub("_NA", "", otu.tax$FT.new.explore)
otu.tab.t$form <- otu.tax$FT.new.explore[match(row.names(otu.tab.t), otu.tax$Label)]
form.list<- otu.tab.t$form
otu.tab.t$form <- NULL
att1 <- aggregate(. ~  form.list, data= otu.tab.t, FUN = "sum")
row.names(att1) = att1$form.list
att1$form.list<- NULL
isme.soil.exploration.type.2 <- data.frame(t(att1))
isme.soil.exploration.type.2$unknown <- isme.soil.exploration.type.2$V1
isme.soil.exploration.type.2$V1<- NULL 

#Final isme datasets include
isme.soil.exploration.type
isme.soil.exploration.type.2

############-----------now the soils dataset-------------################

#Now add this column to the fungal community file
otu.tab.t <- data.frame(t(play2))
otu.tab.t$form <- soil.otu.tax$Exploration_type[match(row.names(otu.tab.t), soil.otu.tax$OTU)]
form.list<- otu.tab.t$form
otu.tab.t$form <- NULL
att1 <- aggregate(. ~  form.list, data= otu.tab.t, FUN = "sum")
row.names(att1) = att1$form.list
att1$form.list<- NULL
soil.exploration.type <- data.frame(t(att1))
soil.exploration.type$unknown <- soil.exploration.type$V1
soil.exploration.type$V1<- NULL 

#Now repeat for updated traits database
otu.tab.t <- data.frame(t(play2))
soil.otu.tax$FT.new.explore <- paste0(soil.otu.tax$FT.new.exploration_type, "_", soil.otu.tax$FT.new.exploration_type.2)
soil.otu.tax$FT.new.explore <- gsub("_NA", "", soil.otu.tax$FT.new.explore)
otu.tab.t$form <- soil.otu.tax$FT.new.explore[match(row.names(otu.tab.t), soil.otu.tax$OTU)]
form.list<- otu.tab.t$form
otu.tab.t$form <- NULL
att1 <- aggregate(. ~  form.list, data= otu.tab.t, FUN = "sum")
row.names(att1) = att1$form.list
att1$form.list<- NULL
soil.exploration.type.2 <- data.frame(t(att1))
soil.exploration.type.2$unknown <- soil.exploration.type.2$V1
soil.exploration.type.2$V1<- NULL 

#Final soils datasets include
soil.exploration.type
soil.exploration.type.2

#Now add the ICP plot, country code, and sampling horizon (for soil samples)
#...to each sampling unit and save
envt.tab$Country_plot

isme.soil.exploration.type$country_plot <- envt.tab$Country_plot[match(row.names(isme.soil.exploration.type), row.names(envt.tab))]
isme.soil.exploration.type.2$country_plot <- envt.tab$Country_plot[match(row.names(isme.soil.exploration.type.2), row.names(envt.tab))]

soil.envt.tab$country_plot <- paste0(soil.envt.tab$Country, "_", soil.envt.tab$Plot)
soil.exploration.type$country_plot <- soil.envt.tab$country_plot[match(row.names(soil.exploration.type), soil.envt.tab$File_name)]
soil.exploration.type.2$country_plot <- soil.envt.tab$country_plot[match(row.names(soil.exploration.type.2), soil.envt.tab$File_name)]
soil.exploration.type$Horizon <- soil.envt.tab$Soil.Horizon[match(row.names(soil.exploration.type), soil.envt.tab$File_name)]
soil.exploration.type.2$Horizon <- soil.envt.tab$Soil.Horizon[match(row.names(soil.exploration.type.2), soil.envt.tab$File_name)]

#Save files
saveRDS(isme.soil.exploration.type, isme.explore.save)
saveRDS(isme.soil.exploration.type.2, isme.explore.2.new.fungal.traits.save)
saveRDS(soil.exploration.type, soil.explore.save)
saveRDS(soil.exploration.type.2, soil.explore.2.new.fungal.traits.save)
