#Assess how PFAM and CAZYymes  vary with exploration type

#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

#Load packages
require(ape)
require(fungaltraits)
require(splitstackshape)
require(vegan)
require(ggplot2)
require(indicspecies)
require(reshape2)
require(ggVennDiagram)
require(purrr)
require(wordcloud)
require(wordcloud2)
require(tm)
require(dplyr)
require(car)
require(psych)
require(devtools)
require(pairwiseAdonis)

#Read in fungal trait data scraped from mycocosm
cazy <- read.csv(cazy.path, row.names = 1)
cazy.2 <- read.csv(cazy.path, row.names = 1)
pfams <- read.csv(pfams.path, row.names = 1)
pfams.2 <- read.csv(pfams.path, row.names = 1)
info <- read.csv(info.path)
ftraits <- fungal_traits()
jgi.use <- read.csv(myco.use)

#Make save file path names
pfam.indicators.save <- pfam.indicators.save.string

#Remove public genomes without PI permission to use
info$permission <- jgi.use$Update_3[match(info$TaxonID, jgi.use$TaxonID)]
info$permission <- ifelse(is.na(info$permission), "APPROVED", info$permission)

#Now remove all denied and pending
info <- info[!info$permission == "DENIED", ]
info <- info[!info$permission == "PENDING", ]

########################## ---- 
#Subset pfams data on nitrogen
nitrogen.list <- pfams.2[grep("Nitrogen", pfams.2$Annotation.Description),]
nitrogen.list.2 <- pfams.2[grep("protease", pfams.2$Annotation.Description),]
nitrogen.list.3 <- pfams.2[grep("peptidase", pfams.2$Annotation.Description),]
nitrogen.list.4 <- pfams.2[grep("amino acid", pfams.2$Annotation.Description),]
nitrogen.list.5 <- pfams.2[grep("peroxidase", pfams.2$Annotation.Description),]
nitrogen.list.6 <- pfams.2[grep("oxidase", pfams.2$Annotation.Description),]
nitrogen.list.7 <- pfams.2[grep("lignin", pfams.2$Annotation.Description),]
nitrogen.list.8 <- pfams.2[grep("Ammonium", pfams.2$Annotation.Description),]
nitrogen.list.9 <- pfams.2[grep("Nitrite", pfams.2$Annotation.Description),]
nitrogen.list.10 <- pfams.2[grep("acetylglucosaminidase", pfams.2$Annotation.Description),]

 
# Merge findings and remove duplicates based on annotation
nitrogen.pfam <- rbind(nitrogen.list, nitrogen.list.2, nitrogen.list.3, nitrogen.list.4,
                       nitrogen.list.5, nitrogen.list.6, 
                       nitrogen.list.7, nitrogen.list.8, nitrogen.list.9, nitrogen.list.10)

nitrogen.pfam <- nitrogen.pfam[!duplicated(nitrogen.pfam$Annotation.Description), ]


########################## ---- 
#Subset pfams data on decomposition related genes
decomp1.list <- pfams.2[grep("Lytic polysaccharide mono-oxygenase", pfams.2$Annotation.Description),]
decomp2.list <- pfams.2[grep("Alpha-L-arabinofuranosidase", pfams.2$Annotation.Description),]
decomp3.list <- pfams.2[grep("Beta-galactosidase", pfams.2$Annotation.Description),]
decomp4.list <- pfams.2[grep("Acetyl xylan esterase", pfams.2$Annotation.Description),]
decomp5.list <- pfams.2[grep("Cutinase", pfams.2$Annotation.Description),]
decomp6.list <- pfams.2[grep("feruloyl esterase", pfams.2$Annotation.Description),]
decomp7.list <- pfams.2[grep("Alpha-L-arabinofuranosidase", pfams.2$Annotation.Description),]
decomp8.list <- pfams.2[grep("Pectinesterase", pfams.2$Annotation.Description),]
decomp9.list <- pfams.2[grep("Pectate lyase", pfams.2$Annotation.Description),]
decomp10.list <- pfams.2[grep("Rhamnogalacturonan lyase", pfams.2$Annotation.Description),]
decomp11.list <- pfams.2[grep("rhamnosidase", pfams.2$Annotation.Description),]
decomp12.list <- pfams.2[grep("Alpha amylase", pfams.2$Annotation.Description),]
decomp13.list <- pfams.2[grep("Catalase", pfams.2$Annotation.Description),]
decomp14.list <- pfams.2[grep("Glyoxal oxidase", pfams.2$Annotation.Description),]
decomp15.list <- pfams.2[grep("Multicopper oxidase", pfams.2$Annotation.Description),]
decomp16.list <- pfams.2[grep("Peroxidase", pfams.2$Annotation.Description),]

# Merge findings and remove duplicates based on annotation
decomposition.pfam <- rbind(decomp1.list, decomp2.list, decomp3.list, decomp4.list,
                            decomp5.list, decomp6.list, decomp7.list, decomp8.list,
                            decomp9.list, decomp10.list,decomp11.list,decomp12.list,decomp13.list,
                            decomp14.list,decomp15.list,decomp16.list)

decomposition.pfam <- decomposition.pfam[!duplicated(decomposition.pfam$Annotation.Description), ]

##########################
########CAZYmes###########
##########################
cazy$Annotation.Description <- NULL
cazy.t <- data.frame(t(cazy))
cazy.t <- cazy.t[rowSums(cazy.t)>0,] #remove taxa not included

#Make envt dataframe 
envt.mat <- data.frame(Taxon = row.names(cazy.t))
envt.mat$Exploration <- info$Exploration_type[match(envt.mat$Taxon, info$TaxonID)]
envt.mat$Assembly.length <- info$Assembly.Length[match(envt.mat$Taxon, info$TaxonID)]
envt.mat$X.Genes <- info$X..Genes[match(envt.mat$Taxon, info$TaxonID)]
envt.mat$Genus <- info$Genus[match(envt.mat$Taxon, info$TaxonID)]
envt.mat$Higher_clade <- ftraits$higher_clade[match(envt.mat$Genus, ftraits$Genus)]

#Now remove any non-assigned taxa
cazy.t$exploration <- envt.mat$Exploration[match(row.names(cazy.t), envt.mat$Taxon)]
cazy.t <- cazy.t[!is.na(cazy.t$exploration),]
envt.mat.2 <- data.frame(Exploration = cazy.t$exploration, Taxon = row.names(cazy.t))
envt.mat.2$assembly <- envt.mat$Assembly.length[match(envt.mat.2$Taxon, envt.mat$Taxon)]

envt.mat.2$genes <- envt.mat$X.Genes[match(envt.mat.2$Taxon, envt.mat$Taxon)]
envt.mat.2$phylum <- envt.mat$Higher_clade[match(envt.mat.2$Taxon, envt.mat$Taxon)]
cazy.t$exploration <- NULL

#Only certain CAZymes columns should be included since there are cateogires of sums of groups
cazy.t.2 <- data.frame(
AA = cazy.t$AA,
CBM = cazy.t$CBM,
CE = cazy.t$CE,
GH = cazy.t$GH,
GT = cazy.t$GT,
PL = cazy.t$PL)
row.names(cazy.t.2) <- row.names(cazy.t)

#Now correct by total CAZymes
cazy.t.2 <- cazy.t.2/cazy.t$CAZy

#Remove the two MD-Mat because there are too few to include or plot
envt.mat.2 <- envt.mat.2[!envt.mat.2$Taxon == "Gaumor1_1",]
envt.mat.2 <- envt.mat.2[!envt.mat.2$Taxon == "Hyssto1",]
cazy.t.2 <- cazy.t.2[!row.names(cazy.t.2) == "Gaumor1_1", ]
cazy.t.2 <- cazy.t.2[!row.names(cazy.t.2) == "Hyssto1", ]
cazy.t <- cazy.t[!row.names(cazy.t) == "Gaumor1_1", ]
cazy.t <- cazy.t[!row.names(cazy.t) == "Hyssto1", ]

#####################Total CAYZMES ----
caz.aov <- aov(cazy.t$CAZy ~ (Exploration + phylum)^2 + assembly + genes, data = envt.mat.2)
anova(caz.aov)
TukeyHSD(caz.aov, "Exploration")

#Visualize the effect
cazy.ggplot <- ggplot(cbind(envt.mat.2, cazy.t$CAZy), aes(x = reorder(Exploration, -cazy.t$CAZy), y = cazy.t$CAZy, color = Exploration))+
  geom_boxplot(show.legend = FALSE)+
  coord_flip()+
  theme_classic()+
  labs(x = "", y = "Total CAZymes (# of protein models)")

#################################################################
####################Constrained approach#########################
#################################################################

#RDA--
bray.dbrda.thing<- capscale(cazy.t.2 ~ Exploration + phylum + assembly + genes, method = "bray", data = envt.mat.2)
sum.bray <- summary(bray.dbrda.thing)
anova(bray.dbrda.thing, by = "term")

#Let's visualize the difference
biplot.stuff <- data.frame(sum.bray$constraints) #sites 
biplot.stuff$Exploration <- envt.mat.2$Exploration
biplot.stuff$Phylum <- envt.mat.2$phylum
biplot.stuff <- biplot.stuff[!biplot.stuff$Exploration == "MD-Mat",] #Remove the MD-Mat because only two points
hull.1 <- biplot.stuff %>% group_by(Exploration) %>% 
  slice(chull(CAP1, CAP2))

#Get vectors
biplot.points <- data.frame(sum.bray$species[,1:2])
biplot.points$label <- row.names(biplot.points)

#Now visualize
ggplot(biplot.stuff, aes(x = CAP1, y = CAP2, color = Exploration)) + 
  geom_point(aes(shape = Phylum), size = 2) + theme_classic()+
  labs(x = "CAP1 (48%)", y = "CAP2 (39%)", color = "") + 
  theme(legend.position = "bottom")+
  geom_polygon(data = hull.1, alpha = 0.2, 
               aes(fill = Exploration,colour = Exploration), show.legend = FALSE)+
  geom_segment(data=biplot.points,aes(x=0,xend=0.4*CAP1,y=0,yend=0.4*CAP2),
             arrow = arrow(length = unit(0.2, "cm")),colour="black", alpha = 1)+
  geom_text(data=biplot.points, aes( x=0.6*CAP1, y=0.6*CAP2, label=label),color="black", size = 4)

#################################################################
###################Differences in rel %##########################
#################################################################
cazy.t.3 <- cazy.t.2
cazy.t.3$Exploration <- envt.mat.2$Exploration
cazy.t.3$assembly <- envt.mat.2$assembly
cazy.t.3$genes <- envt.mat.2$genes
cazy.t.3$Exploration <- envt.mat.2$Exploration
cazy.t.3$assembly <- envt.mat.2$assembly
cazy.t.3$genes <- envt.mat.2$genes
cazy.t.3$phylum <- envt.mat.2$phylum
cazy.t.4 <- cazy.t

#Remove the MD-Mat because there are only two taxa
cazy.t.3 <- cazy.t.3[!cazy.t.3$Exploration == "MD-Mat", ]

aa.mod <- aov(AA ~ Exploration + assembly + genes + phylum, data = cazy.t.3) #Almost significant
qqnorm(aa.mod$residuals)
Anova(aa.mod, type = "III") #N.S.

cbm.mod <- aov(CBM ~ Exploration + assembly + genes + phylum, data = cazy.t.3) #Almost significant
qqnorm(cbm.mod$residuals)
Anova(cbm.mod, type = "III") #Big exploration type effect
TukeyHSD(cbm.mod, "Exploration")

ce.mod <- aov(CE ~ Exploration + assembly + genes + phylum, data = cazy.t.3) #Almost significant
qqnorm(ce.mod$residuals)
Anova(ce.mod, type = "III") #Big exploration type effect

gh.mod <- aov(GH ~ Exploration + assembly + genes + phylum, data = cazy.t.3) #Almost significant
qqnorm(gh.mod$residuals)
Anova(gh.mod, type = "III") #N.S.

gt.mod <- aov(GT ~ Exploration + assembly + genes + phylum, data = cazy.t.3) #Almost significant
qqnorm(gt.mod$residuals)
Anova(gt.mod, type = "III") #Big exploration type effect
TukeyHSD(gt.mod, "Exploration")

pl.mod <- aov(PL ~ Exploration + assembly + genes + phylum, data = cazy.t.3) #Almost significant
qqnorm(pl.mod$residuals)
Anova(pl.mod, type = "III") #Big exploration type effect

#Let's plot CBM -- low biomass have more
cbm.ggplot <- ggplot(cazy.t.3, aes(x = reorder(Exploration, CBM), y = CBM, color = Exploration))+
  geom_boxplot(show.legend = FALSE)+
  coord_flip()+
  theme_classic()+
  labs(x = "", y = "Carbohydrate-Binding modules")

#Let's plot CE
ce.ggplot <- ggplot(cazy.t.3, aes(x = reorder(Exploration, CE), y = CE, color = Exploration))+
  geom_boxplot(show.legend = FALSE)+
  coord_flip()+
  theme_classic()+
  labs(x = "", y = "Carbohydrate esterases")

#Let's plot GT
gt.ggplot <- ggplot(cazy.t.3, aes(x = reorder(Exploration, -GT), y = GT, color = Exploration))+
  geom_boxplot(show.legend = FALSE)+
  coord_flip()+
  theme_classic()+
  labs(x = "", y = "Glycosyl Transferases")

#Let's plot PL -- highly variable
pl.ggplot <- ggplot(cazy.t.3, aes(x = reorder(Exploration, PL), y = PL, color = Exploration))+
  geom_boxplot(show.legend = FALSE)+
  coord_flip()+
  theme_classic()+
  labs(x = "", y = "Polysaccharide Lyases")

#Plot all four together
errrthing.together <- cowplot::plot_grid(cbm.ggplot, ce.ggplot, pl.ggplot, gt.ggplot)

##########################
########PFAMs#############
##########################

#Make data frames, including the nitrogen specific pfam results
nitrogen.pfam$Annotation.Description <- NULL
nitrogen.pfam.t <- data.frame(t(nitrogen.pfam))
nitrogen.pfam.t <- nitrogen.pfam.t[rowSums(nitrogen.pfam.t[])>0,] #remove taxa not included
nitrogen.pfam.t <- nitrogen.pfam.t[, colSums(nitrogen.pfam.t != 0) > 0] #remove empty pfams

#Make data frames, including the decomposition specific pfam results
decomposition.pfam$Annotation.Description <- NULL
decomposition.pfam.t <- data.frame(t(decomposition.pfam))
decomposition.pfam.t <- decomposition.pfam.t[rowSums(decomposition.pfam.t[])>0,] #remove taxa not included
decomposition.pfam.t <- decomposition.pfam.t[, colSums(decomposition.pfam.t != 0) > 0] #remove empty pfams

#Must modify the full data so we can relative N genes by total pfams
pfams$Annotation.Description <- NULL
pfams.t <- data.frame(t(pfams))
pfams.t <- pfams.t[rowSums(pfams.t[])>0,] #remove taxa not included
pfams.t <- pfams.t[, colSums(pfams.t != 0) > 0] #remove empty pfams

#Now let's divide everything by the total number of PFAMs (so column 1)
nitrogen.pfam.t <- nitrogen.pfam.t/pfams.t[,1]
decomposition.pfam.t <- decomposition.pfam.t/pfams.t[,1]

#Now let's divide everything by the total number of PFAMs (so column 1)
pfams.t.r <- pfams.t/pfams.t[,1]
pfams.t.r$PFAMs <- NULL

#Make envt dataframe 
envt.mat <- data.frame(Taxon = row.names(pfams.t.r))
envt.mat$Exploration <- info$Exploration_type[match(envt.mat$Taxon, info$TaxonID)]

#Now remove any non-assigned taxa
nitrogen.pfam.t$exploration <- envt.mat$Exploration[match(row.names(nitrogen.pfam.t), envt.mat$Taxon)]
nitrogen.pfam.t <- nitrogen.pfam.t[!is.na(nitrogen.pfam.t$exploration),]

decomposition.pfam.t$exploration <- envt.mat$Exploration[match(row.names(decomposition.pfam.t), envt.mat$Taxon)]
decomposition.pfam.t <- decomposition.pfam.t[!is.na(decomposition.pfam.t$exploration),]

pfams.t.r$exploration <- envt.mat$Exploration[match(row.names(pfams.t.r), envt.mat$Taxon)]
pfams.t.r <- pfams.t.r[!is.na(pfams.t.r$exploration),]

envt.mat.2 <- data.frame(Exploration = pfams.t.r$exploration, Taxon = row.names(pfams.t.r))
envt.mat.2$genes <- info$X..Genes[match(envt.mat.2$Taxon, info$TaxonID)]
envt.mat.2$genome <- info$Assembly.Length[match(envt.mat.2$Taxon, info$TaxonID)]
envt.mat.2$Genus <- info$Genus[match(envt.mat.2$Taxon, info$TaxonID)]
envt.mat.2$Higher_clade <- ftraits$higher_clade[match(envt.mat.2$Genus, ftraits$Genus)]
pfams.t.r$exploration <- NULL
nitrogen.pfam.t$exploration <- NULL
decomposition.pfam.t$exploration <- NULL

#Remove the two MD-Mat because there are too few to include or plot
envt.mat.2 <- envt.mat.2[!envt.mat.2$Taxon == "Gaumor1_1",]
envt.mat.2 <- envt.mat.2[!envt.mat.2$Taxon == "Hyssto1",]
pfams.t.r <- pfams.t.r[!row.names(pfams.t.r) == "Gaumor1_1", ]
pfams.t.r <- pfams.t.r[!row.names(pfams.t.r) == "Hyssto1", ]
nitrogen.pfam.t <- nitrogen.pfam.t[!row.names(nitrogen.pfam.t) == "Gaumor1_1", ]
nitrogen.pfam.t <- nitrogen.pfam.t[!row.names(nitrogen.pfam.t) == "Hyssto1", ]
decomposition.pfam.t <- decomposition.pfam.t[!row.names(decomposition.pfam.t) == "Gaumor1_1", ]
decomposition.pfam.t <- decomposition.pfam.t[!row.names(decomposition.pfam.t) == "Hyssto1", ]

#################################################################
####################Constrained approach#########################
#################################################################
#RDA--
#bray.dbrda.thing<- capscale(vegdist(pfams.t.r, method = "bray") ~ Exploration + genes + genome + Higher_clade, data = envt.mat.2)
#sum.bray <- summary(bray.dbrda.thing)
#anova(bray.dbrda.thing, by = "terms")

#RDA-- nitrogen only
nitrogen.bray.dbrda.thing<- capscale(nitrogen.pfam.t ~ Exploration + genes + genome + Higher_clade, method = "bray", data = envt.mat.2)
sum.bray <- summary(nitrogen.bray.dbrda.thing)
anova(nitrogen.bray.dbrda.thing, by = "terms")

#RDA-- decomposition genes only
de.bray.dbrda.thing<- capscale(decomposition.pfam.t ~ Exploration + genes + genome + Higher_clade, method = "bray", data = envt.mat.2)
sum.bray.d <- summary(de.bray.dbrda.thing)
anova(de.bray.dbrda.thing, by = "terms")

#Get the VIF scores
vif.cca(nitrogen.bray.dbrda.thing)
vif.cca(de.bray.dbrda.thing)

#Let's visualize the difference - nitrogen
biplot.stuff <- data.frame(sum.bray$constraints) #sites 
biplot.stuff$Exploration <- envt.mat.2$Exploration
biplot.stuff$Phylum <- envt.mat.2$Higher_clade
hull.1 <- biplot.stuff %>% group_by(Exploration) %>% 
  slice(chull(CAP1, CAP2))

#Let's visualize the difference - decomp
biplot.stuff.d <- data.frame(sum.bray.d$constraints) #sites 
biplot.stuff.d$Exploration <- envt.mat.2$Exploration
biplot.stuff.d$Phylum <- envt.mat.2$Higher_clade
hull.1.d <- biplot.stuff.d %>% group_by(Exploration) %>% 
  slice(chull(CAP1, CAP2))

#Set axis order
biplot.stuff$Exploration <- factor(biplot.stuff$Exploration, levels = c("C", "SD", "MD-Smooth", "MD-Fringe", "LD"))

#Now visualize
nitrogen.pfam.results <- ggplot(biplot.stuff, aes(x = CAP1, y = CAP2, color = Exploration)) + 
  geom_point(aes(shape = Phylum), size = 2, show.legend = FALSE) + theme_classic()+ 
  labs(x = "CAP1 (68%)", y = "CAP2 (17%)", color = "") + 
  theme(legend.position = "bottom")+
  scale_color_manual(values = c("aquamarine4", "cadetblue1", "darkorchid", "darkslateblue", "coral2"))+
  geom_polygon(data = hull.1, alpha = 0.1, 
               aes(fill = Exploration,color = Exploration), show.legend = FALSE)

#Set axis order
biplot.stuff.d$Exploration <- factor(biplot.stuff.d$Exploration, levels = c("C", "SD", "MD-Smooth", "MD-Fringe", "LD"))

#Now visualize
decomp.pfam.results <- ggplot(biplot.stuff.d, aes(x = CAP1, y = CAP2, color = Exploration)) + 
  geom_point(aes(shape = Phylum), size = 2, show.legend = FALSE) + theme_classic()+ 
  labs(x = "CAP1 (46%)", y = "CAP2 (31%)", color = "") + 
  scale_color_manual(values = c("aquamarine4", "cadetblue1", "darkorchid", "darkslateblue", "coral2"))+
  theme(legend.position = "bottom")+
  geom_polygon(data = hull.1.d, alpha = 0.1, 
               aes(fill = Exploration, color = Exploration), show.legend = FALSE)

#################################################################
#What about the total relative abundacne of N and decomp related genes?
#################################################################

#Nitrogen
pfam.sum.df <- data.frame(Nitrogen = rowSums(nitrogen.pfam.t))
pfam.sum.df <- cbind(pfam.sum.df, envt.mat.2)

nit.mod <- aov(Nitrogen ~ Higher_clade + Exploration + genome + genes, data = pfam.sum.df) #Almost significant
qqnorm(nit.mod$residuals)
Anova(nit.mod, type = "II") #N.S.
TukeyHSD(nit.mod, "Exploration")

#Let's plot total N cycling pfams - return
nit.ggplot <- ggplot(pfam.sum.df, aes(x = reorder(Exploration, -Nitrogen), y = Nitrogen, fill = Exploration))+
  geom_boxplot(show.legend = FALSE)+
  coord_flip()+
  theme_classic()+
  labs(x = "", y = "Nitrogen cycling proteins")

cowplot::plot_grid(nitrogen.pfam.results, nit.ggplot)

#Decomposition
d.pfam.sum.df <- data.frame(Decomposition = rowSums(decomposition.pfam.t))
d.pfam.sum.df <- cbind(d.pfam.sum.df, envt.mat.2)

decomp.mod <- aov(rank(Decomposition) ~ Exploration + Higher_clade + genome + genes, data = d.pfam.sum.df) #Almost significant
qqnorm(decomp.mod$residuals)
Anova(decomp.mod, type = "II") #Significant
TukeyHSD(decomp.mod, "Exploration")

#Let's plot total decomposition pfams - return
dec.ggplot <- ggplot(d.pfam.sum.df, aes(x = reorder(Exploration, -Decomposition), y = Decomposition, fill = Exploration))+
  geom_boxplot(show.legend = FALSE)+
  coord_flip()+
  theme_classic()+
  labs(x = "", y = "Decomposition proteins")

cowplot::plot_grid(decomp.pfam.results, dec.ggplot,
                   nitrogen.pfam.results, nit.ggplot)

#################################################################
####################exploratory approach#########################
#################################################################

#PERMANOVA---
adonis2(vegdist(pfams.t.r, method = "bray") ~ Exploration + genes + genome + Higher_clade, data = envt.mat.2)

#Pairwise adonis2
pairwise.adonis2(vegdist(pfams.t.r, method = "bray") ~ Exploration, 
                                   data = envt.mat.2, permutations = 999)
                 
                 
#Plot the bray curtis dissimilarity by exploration type
bray.pfam <- vegdist(pfams.t.r, method = "bray")
pfam.br <- data.frame(colMeans(as.data.frame(as.matrix(bray.pfam))))
colnames(pfam.br) = "Bray"
pfam.br$Exploration <- envt.mat.2$Exploration[match(row.names(pfam.br), envt.mat.2$Taxon)]

#Set axis order
pfam.br$Exploration <- factor(pfam.br$Exploration, levels = c("C", "SD", "MD-Smooth", "MD-Fringe", "LD"))

#Now visualize
pfam.bray <- ggplot(pfam.br, aes(x = reorder(Exploration, Bray), y = Bray, fill = Exploration)) +
  geom_boxplot(show.legend = FALSE)+
  scale_fill_manual(values = c("aquamarine4", "cadetblue1", "darkorchid", "darkslateblue", "coral2"))+
  theme_classic()+
  coord_flip()+
  labs(y = "PFAM comp. (BC Diss.)", x = "")

#Now plot everything together
pfam.bray

cowplot::plot_grid(pfam.bray, decomp.pfam.results, nitrogen.pfam.results)


##################################################################
#######Are there any indicator pfams of the different groups?#####
##################################################################
n.cycle.idic <- multipatt(nitrogen.pfam.t, envt.mat.2$Exploration, 
                    control = how(nperm=999), duleg=TRUE) 

n.cycle.idic.results <- n.cycle.idic$sign
n.cycle.idic.results <- n.cycle.idic.results[n.cycle.idic.results$p.value < 0.05,]
n.cycle.idic.results <- na.omit(n.cycle.idic.results)

decomp.idic <- multipatt(decomposition.pfam.t, envt.mat.2$Exploration, 
                          control = how(nperm=999), duleg=TRUE) 

decomp.idic.results <- decomp.idic$sign
decomp.idic.results <- decomp.idic.results[decomp.idic.results$p.value < 0.05,]
decomp.idic.results <- na.omit(decomp.idic.results)


# Modify n.cycle.idic.results in place
for (i in 1:nrow(n.cycle.idic.results)) {  # Loop through rows
  for (j in 1:5) {  # Loop through first 5 columns
    if (n.cycle.idic.results[i, j] == 1) {
      n.cycle.idic.results$new_column[i] <- colnames(n.cycle.idic.results)[j]  # Assign column name
      break  # Stop checking after the first match
    }
  }
}


# Modify decomp.idic.results in place
for (i in 1:nrow(decomp.idic.results)) {  # Loop through rows
  for (j in 1:5) {  # Loop through first 5 columns
    if (decomp.idic.results[i, j] == 1) {
      decomp.idic.results$new_column[i] <- colnames(decomp.idic.results)[j]  # Assign column name
      break  # Stop checking after the first match
    }
  }
}


#Now make new data frames which we can use to plot!
n.pfma.fin <- data.frame(Exploration = n.cycle.idic.results$new_column, Stat = n.cycle.idic.results$stat, pfam = row.names(n.cycle.idic.results))
n.pfma.fin$Annotation <- pfams.2$Annotation.Description[match(n.pfma.fin$pfam, row.names(pfams.2))]
n.pfma.fin$Group <- rep("Nitrogen cycling", length(n.pfma.fin$Exploration))

#Now make new data frames which we can use to plot!
decomp.pfma.fin <- data.frame(Exploration = decomp.idic.results$new_column, Stat = decomp.idic.results$stat, pfam = row.names(decomp.idic.results))
decomp.pfma.fin$Annotation <- pfams.2$Annotation.Description[match(decomp.pfma.fin$pfam, row.names(pfams.2))]
decomp.pfma.fin$Group <- rep("Decomposition", length(decomp.pfma.fin$Exploration))

#We can now put them together
indicators <- rbind(decomp.pfma.fin, n.pfma.fin)
indicators$Exploration <- gsub("s.", "", indicators$Exploration)

#Now save this file
write.csv(indicators, pfam.indicators.save)
