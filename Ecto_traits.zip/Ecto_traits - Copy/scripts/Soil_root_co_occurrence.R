#Model the co-occurrence among different exploration types

#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

require(Hmisc)
require(corrplot)
require(cowplot)
require(ggplot2)
require(fungaltraits)
dd <- fungal_traits()
library(rworldmap)
library(rworldxtra)
library(mapdata)

icp.dat <- read.csv(icp.data.envt)
isme.explorers.2 <- readRDS(isme.explore.2.new.fungal.traits)
isme.explorers <- readRDS(isme.explore)
soil.explorers <- readRDS(soil.explore)
soil.exploreres.2 <- readRDS(soil.explore.2.new.fungal.traits)
guilds.data <- readRDS(saprotroph.save)

#Match the guild data
guilds.data$country_plot <- soil.explorers$country_plot[match(row.names(guilds.data), row.names(soil.explorers))]

guilds.data$total.pathogens <- guilds.data$Plant.Pathogen + guilds.data$Plant.Pathogen.Wood.Saprotroph + guilds.data$Animal.Pathogen.Endophyte.Epiphyte.Plant.Pathogen+
  guilds.data$Animal.Pathogen.Endophyte.Plant.Pathogen.Wood.Saprotroph + guilds.data$Endophyte.Plant.Pathogen + guilds.data$Endophyte.Plant.Pathogen.Undefined.Saprotroph+
  guilds.data$Dung.Saprotroph.Plant.Pathogen + guilds.data$Leaf.Saprotroph.Plant.Pathogen.Undefined.Saprotroph.Wood.Saprotroph + guilds.data$Endophyte.Fungal.Parasite.Plant.Pathogen

guilds.data$total.saprotrophs <- guilds.data$Soil.Saprotroph + guilds.data$Dung.Saprotroph.Endophyte + guilds.data$Dung.Saprotroph.Endophyte.Wood.Saprotroph +
  guilds.data$Dung.Saprotroph.Plant.Pathogen + guilds.data$Dung.Saprotroph.Wood.Saprotroph + guilds.data$Leaf.Saprotroph + guilds.data$Leaf.Saprotroph.Plant.Pathogen.Undefined.Saprotroph.Wood.Saprotroph+
  guilds.data$Leaf.Saprotroph.Wood.Saprotroph + guilds.data$Wood.Saprotroph + guilds.data$Litter.Saprotroph + guilds.data$Litter.Saprotroph.Soil.Saprotroph +
  guilds.data$Undefined.Saprotroph + guilds.data$Plant.Pathogen.Wood.Saprotroph + guilds.data$Fungal.Parasite.Soil.Saprotroph.Undefined.Saprotroph + guilds.data$Animal.Pathogen.Undefined.Saprotroph +
  guilds.data$Animal.Endosymbiont.Undefined.Saprotroph + guilds.data$Endophyte.Plant.Pathogen.Undefined.Saprotroph + guilds.data$Animal.Pathogen.Endophyte.Plant.Pathogen.Wood.Saprotroph

#Add  pathogen and saprotroph categories to the models
isme.explorers$total.pathogens <- guilds.data$total.pathogens[match(isme.explorers$country_plot, guilds.data$country_plot)]
isme.explorers$total.saprotrophs <- guilds.data$total.saprotrophs[match(isme.explorers$country_plot, guilds.data$country_plot)]

#Model the root tip communities first, but remove the unknown and country_plot columns
isme.explorers <- subset(isme.explorers, select = -c(unknown, country_plot))
colnames(isme.explorers) <- c("C", "LD", "MAT", "MD-F", "MD-S", "SD-C", "SD-D", "Paths", "Saps")
row.names(isme.explorers) <- c("C", "LD", "MAT", "MD-F", "MD-S", "SD-C", "SD-D", "Paths", "Saps")

#Try removing the MAT type because they are too rare to include
isme.explorers$MAT <- NULL

#Make a log corrected data frame
#This function will remove infinite values
inf2NA <- function(x) { x[is.infinite(x)] <- NA; x }
res2.root.2 <- rcorr(as.matrix(inf2NA(log(as.matrix(isme.explorers)))))

#Insignificant correlations are left blank, degree of significance is shown
corrplot(res2.root.2$r, p.mat = res2.root.2$P, method = 'color', diag = FALSE, type = 'upper',
         sig.level = c(0.001, 0.01, 0.05), pch.cex = 0.9, col = COL2('PiYG'),
         insig = 'label_sig', pch.col = 'grey20', order = 'original', tl.col="black")


#################################################
#######Now repeat for the soil environment#######
#################################################

#Add  pathogen and saprotroph categories to the models
soil.explorers$total.pathogens <- guilds.data$total.pathogens[match(soil.explorers$country_plot, guilds.data$country_plot)]
soil.explorers$total.saprotrophs <- guilds.data$total.saprotrophs[match(soil.explorers$country_plot, guilds.data$country_plot)]

soil.explorers <- subset(soil.explorers, select = -c(unknown, country_plot, Horizon))
colnames(soil.explorers) <- c("C", "LD", "MAT", "MD-F", "MD-S", "SD-C", "SD-D", "Paths", "Saps")
row.names(soil.explorers) <- c("C", "LD", "MAT", "MD-F", "MD-S", "SD-C", "SD-D", "Paths", "Saps")

#Make a log corrected data frame
res2.soil.2 <- rcorr(as.matrix(inf2NA(as.matrix(100*soil.explorers))))

# Insignificant correlations are left blank, degree of significance is shown
corrplot(res2.soil.2$r, p.mat = res2.soil.2$P, method = 'color', diag = FALSE, type = 'upper',
         sig.level = c(0.001, 0.01, 0.05), pch.cex = 0.9, col = COL2('PiYG'),
         insig = 'label_sig', pch.col = 'grey20', order = 'original', tl.col="black")


##################################################################
#####Visualize the most interesting and strong correlations#######
##################################################################


##########################################################################
#######correlations among root and soil communities rel. abundances#######
##########################################################################

isme.explorers <- readRDS(isme.explore)
soil.explorers <- readRDS(soil.explore)

#Merge df by country_plot
tog.exp <- merge(isme.explorers, soil.explorers, by = 'country_plot')
tog.exp$Tree_type <- icp.dat$Tree_type[match(tog.exp$country_plot, icp.dat$country_plot)]
tog.exp.sp <- split(tog.exp, tog.exp$Horizon)
tog.exp.sp$Org <- tog.exp.sp$Org[!is.na(tog.exp.sp$Org$Tree_type), ]

#this function will remove infinite values
inf2NA <- function(x) { x[is.infinite(x)] <- NA; x }

#Get stats
#Sig. MDF
cor.test(inf2NA(log(tog.exp.sp$Org$medium.distance_fringe.x)), 
                inf2NA(log(tog.exp.sp$Org$medium.distance_fringe.y)), use="pairwise.complete.obs")
#N.Sig. LD
cor.test(inf2NA(log(tog.exp.sp$Org$long.distance.x)), 
         inf2NA(log(tog.exp.sp$Org$long.distance.y)), use="pairwise.complete.obs")
#N.Sig. C
cor.test(inf2NA(log(tog.exp.sp$Org$contact.x)), 
         inf2NA(log(tog.exp.sp$Org$contact.y)), use="pairwise.complete.obs")

#N.Sig. SDC-C
cor.test(inf2NA(log(tog.exp.sp$Org$short.distance_coarse.x)), 
         inf2NA(log(tog.exp.sp$Org$short.distance_coarse.y)), use="pairwise.complete.obs")

#N. Sig. SDC-D
cor.test(inf2NA(log(tog.exp.sp$Org$short.distance_delicate.x)), 
         inf2NA(log(tog.exp.sp$Org$short.distance_delicate.y)), use="pairwise.complete.obs")


#Significant differences?
t.test(inf2NA(log10(tog.exp.sp$Org$medium.distance_fringe.x)), 
       inf2NA(log10(tog.exp.sp$Org$medium.distance_fringe.y)), use="pairwise.complete.obs")

t.test(inf2NA(log10(tog.exp.sp$Org$medium.distance_smooth.x)), 
       inf2NA(log10(tog.exp.sp$Org$medium.distance_smooth.y)), use="pairwise.complete.obs")

t.test(inf2NA(log10(tog.exp.sp$Org$long.distance.x)), 
       inf2NA(log10(tog.exp.sp$Org$long.distance.y)), use="pairwise.complete.obs")

t.test(inf2NA(log10(tog.exp.sp$Org$short.distance_coarse.x)), 
       inf2NA(log10(tog.exp.sp$Org$short.distance_coarse.y)), use="pairwise.complete.obs")

t.test(inf2NA(log10(tog.exp.sp$Org$contact.x)), 
       inf2NA(log10(tog.exp.sp$Org$contact.y)), use="pairwise.complete.obs")

t.test(inf2NA(log10(tog.exp.sp$Org$short.distance_delicate.x)), 
       inf2NA(log10(tog.exp.sp$Org$short.distance_delicate.y)), use="pairwise.complete.obs")

#And with pathogens

MD_F <- ggplot(tog.exp.sp$Org, aes(x = log10(100*medium.distance_fringe.x), 
                           y = log10(100*medium.distance_fringe.y)))+ 
  geom_abline (slope=1, linetype = "dashed", color="black")+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  theme(aspect.ratio = 1)+
  xlim(c(-1.1, 1.7)) + ylim(c(-1.1, 1.7))+
  geom_smooth(method = 'lm', formula = y~x, color = "black")+
  labs(y = "MD-F roots log(%)", 
       x = "MD-F soils log(%)")+
  theme_classic()+  scale_color_manual(values = c("purple", "green"))


C <- ggplot(tog.exp.sp$Org, aes(x = log10(100*contact.x), 
                                   y = log10(100*contact.y)))+ 
    geom_abline (slope=1, linetype = "dashed", color="black")+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  theme(aspect.ratio = 1)+
  xlim(c(-1.25, 1.7)) + ylim(c(-1.25, 1.7))+
 # geom_smooth(method = 'lm', formula = y~x, color = "black")+
  labs(y = "C roots log(%)", 
       x = "C soils log(%)")+
  theme_classic()+  scale_color_manual(values = c("purple", "green"))

LD <- ggplot(tog.exp.sp$Org, aes(x = log10(100*long.distance.x), 
                                y = log10(100*long.distance.y)))+ 
  geom_abline (slope=1, linetype = "dashed", color="black")+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  theme(aspect.ratio = 1)+
  xlim(c(-2, 1.25)) + ylim(c(-2, 1.25))+
  # geom_smooth(method = 'lm', formula = y~x, color = "black")+
  labs(y = "LD roots log(%)", 
       x = "LD soils log(%)")+
  theme_classic()+  scale_color_manual(values = c("purple", "green"))

SD_C <- ggplot(tog.exp.sp$Org, aes(x = log10(100*short.distance_coarse.x), 
                                 y = log10(100*short.distance_coarse.y)))+ 
    geom_abline (slope=1, linetype = "dashed", color="black")+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  theme(aspect.ratio = 1)+
  xlim(c(-2, 1.2)) + ylim(c(-2, 1.2))+
  # geom_smooth(method = 'lm', formula = y~x, color = "black")+
  labs(y = "SD-C roots log(%)", 
       x = "SD-C soils log(%)")+
  theme_classic()+  scale_color_manual(values = c("purple", "green"))

SD_D <- ggplot(tog.exp.sp$Org, aes(x = log10(100*short.distance_delicate.x), 
                                   y = log10(100*short.distance_delicate.y)))+ 
    geom_abline (slope=1, linetype = "dashed", color="black")+
  
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  theme(aspect.ratio = 1)+
  xlim(c(-1.5, 1.75)) + ylim(c(-1.5, 1.75))+
 # geom_smooth(method = 'lm', formula = y~x, color = "black")+
  labs(y = "SD-D roots log(%)", 
       x = "SD-D soils log(%)")+
  theme_classic()+  scale_color_manual(values = c("purple", "green"))

MD_S <- ggplot(tog.exp.sp$Org, aes(x = log10(100*medium.distance_smooth.x), 
                                   y = log10(100*medium.distance_smooth.y)))+ 
    geom_abline (slope=1, linetype = "dashed", color="black")+
  geom_point(aes(color = Tree_type), show.legend = FALSE)+
  theme(aspect.ratio = 1)+
  xlim(c(-1, 2)) + ylim(c(-1, 2))+
  # geom_smooth(method = 'lm', formula = y~x, color = "black")+
  labs(y = "MD-S roots log(%)", 
       x = "MD-S soils log(%)")+
  theme_classic()+  scale_color_manual(values = c("purple", "green"))

plot_grid(C, SD_D, SD_C, MD_S, MD_F, LD, ncol = 3, align = "tblr", axes = "vh")


#############################################################################
###Let's make us a nice little map of the sites with overlapping locations###
#############################################################################
tog.exp.sp$Org$Lat <- icp.dat$lat[match(tog.exp.sp$Org$country_plot, icp.dat$country_plot)]
tog.exp.sp$Org$Long <- icp.dat$long[match(tog.exp.sp$Org$country_plot, icp.dat$country_plot)]

#correct
#tog.exp.sp$Org$Latitude_verify<- tog.exp.sp$Org$Lat*0.0001
#tog.exp.sp$Org$Longitude_verify<- tog.exp.sp$Org$Long*0.0001

#Get the world map
worldMap <- getMap()
countries<- as.vector(worldMap$NAME)
europeanUnion<- countries
# Member States of the European Union

# Select only the index of states member of the E.U.
indEU <- which(worldMap$NAME%in%europeanUnion)

# Extract longitude and latitude border's coordinates of members states of E.U. 
europeCoords <- lapply(indEU, function(i){
  df <- data.frame(worldMap@polygons[[i]]@Polygons[[1]]@coords)
  df$region =as.character(worldMap$NAME[i])
  colnames(df) <- list("long", "lat", "region")
  return(df)
})

europeCoords <- do.call("rbind", europeCoords)

#For the purpose of this example, we’ll assign some random values to each country.

# Add some data for each member
value <- sample(x = seq(1,1,by = 1), size = 1,
                replace = TRUE)
europeanUnionTable <- data.frame(country = europeanUnion, value = value)
europeCoords$value <- europeanUnionTable$value[match(europeCoords$region,europeanUnionTable$country)]

length((tog.exp.sp$Org$country_plot))
#Make the map
map<- ggplot() + 
  geom_polygon(data = europeCoords, aes(x = long, y = lat, group = region),
               colour = "white", fill = "grey", size = 0.1)+
  coord_map(xlim = c(-6, 31),  ylim = c(38, 67))+
  theme(legend.key=element_blank())+
  theme(panel.background = element_rect(fill = "white", color = "black"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank())+
  labs(x = "Longitude (°)", y = "Latitude (°)", fill = "")+
             geom_point(data=tog.exp.sp$Org, aes(x = Long, y = Lat, fill = Tree_type), 
                        size = 2, shape = 21, alpha = 1, show.legend = TRUE)+
             theme(legend.background = element_blank())+
              scale_fill_manual(values = c("purple", "green"))+
             theme(plot.margin=grid::unit(c(0,0.5,0.5,1), "cm"))+ #T,r,b,l
             theme(axis.ticks = element_blank())+
             theme(axis.line = element_blank())+
             theme(axis.text.x = element_text(family="sans", size = 0, color = "black"))+
             theme(axis.text.y = element_text(family="sans", size = 0, color = "black"))+
             theme(axis.title.x = element_text(family="sans", size = 0, color = "black"))+
             theme(axis.title.y = element_text(family="sans", size = 0, color = "black"))
           
