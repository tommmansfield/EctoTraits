#Assess how PFAM and CAZYymes  vary with exploration type

#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

#Load packages
require(ape)
require(fungaltraits)
require(splitstackshape)
require(vegan)
require(ggplot2)
require(indicspecies)
require(reshape2)
require(ggVennDiagram)
require(purrr)
require(wordcloud)
require(wordcloud2)
require(tm)

#Read in fungal trait data scraped from mycocosm
cazy <- read.csv(cazy.path, row.names = 1)
cazy.2 <- read.csv(cazy.path, row.names = 1)
pfams <- read.csv(pfams.path, row.names = 1)
pfams.2 <- read.csv(pfams.path, row.names = 1)
info <- read.csv(info.path)
ftraits <- fungal_traits()

##########################
########CAZYmes###########
##########################
cazy$Annotation.Description <- NULL
cazy.t <- data.frame(t(cazy))
cazy.t <- cazy.t[rowSums(cazy.t[])>0,] #remove taxa not included

#Make envt dataframe 
envt.mat <- data.frame(Taxon = row.names(cazy.t))
envt.mat$Exploration <- info$Exploration_type[match(envt.mat$Taxon, row.names(cazy.t))]

#Now remove any non-assigned taxa
cazy.t$exploration <- envt.mat$Exploration[match(row.names(cazy.t), envt.mat$Taxon)]
cazy.t <- cazy.t[!is.na(cazy.t$exploration),]
envt.mat.2 <- data.frame(Exploration = cazy.t$exploration, Taxon = row.names(cazy.t))
cazy.t$exploration <- NULL

#Only certain CAZymes columns should be included since there are cateogires of sums of groups
cazy.t.2 <- data.frame(
AA = cazy.t$AA,
CBM = cazy.t$CBM,
CE = cazy.t$CE,
GH = cazy.t$GH,
GT = cazy.t$GT,
PL = cazy.t$PL)

#Now correct by total CAZymes
cazy.t.2 <- cazy.t.2/cazy.t$CAZy

#################################################################
####################Constrained approach#########################
#################################################################
#RDA--
bray.dbrda.thing<- capscale(vegdist(cazy.t.2, method = "bray") ~ Exploration, data = envt.mat.2)
sum.bray <- summary(bray.dbrda.thing)
anova(bray.dbrda.thing)

#Let's visualize the difference
biplot.stuff <- data.frame(sum.bray$sites)
biplot.stuff$Exploration <- envt.mat.2$Exploration
biplot.stuff.sp <- data.frame(sum.bray$centroids)
biplot.stuff.sp$Exploration.type <- row.names(biplot.stuff.sp)
biplot.stuff.sp$Exploration.type <- gsub("Exploration", "", biplot.stuff.sp$Exploration.type)

#Now visualize
ggplot(biplot.stuff.sp, aes(x = CAP1, y = CAP2, color = Exploration.type)) + 
  geom_point(data = biplot.stuff, aes(x = CAP1, y = CAP2, color = Exploration), 
             alpha = 0.25, size = 3, show.legend = TRUE)+
  geom_point(shape = "+", size = 10) + theme_classic()+
  labs(x = "CAP1 (48%)", y = "CAP2 (39%)", color = "")

#################################################################
####################exploratory approach#########################
#################################################################

#PERMANOVA---
adonis2(vegdist(cazy.t.2, method = "bray") ~ Exploration, data = envt.mat.2)

#NMDS---
meta.bray <- pcoa(vegdist(cazy.t.2, type = "bray"))
biplot.stuff.2 <- data.frame(meta.bray$vectors[,1:2])
biplot.stuff.2$Exploration <- envt.mat.2$Exploration

#Now visualize
ggplot(biplot.stuff.2, aes(x = Axis.1, y = Axis.2, color = Exploration)) + 
  geom_point() + theme_classic()

#################################################################
###################Differences in rel %##########################
#################################################################
cazy.t.3 <- cazy.t.2
cazy.t.3$Exploration <- envt.mat.2$Exploration

kruskal.test(cazy.t.3$AA, cazy.t.3$Exploration)
kruskal.test(cazy.t.3$CBM, cazy.t.3$Exploration) #Sig 
kruskal.test(cazy.t.3$CE, cazy.t.3$Exploration) #Sig
kruskal.test(cazy.t.3$GH, cazy.t.3$Exploration) #Sig
kruskal.test(cazy.t.3$GT, cazy.t.3$Exploration) #Sig
kruskal.test(cazy.t.3$PL, cazy.t.3$Exploration) #Sig

#Now, let's visualize the effects
cazy.t.4 <- cazy.t.2
cazy.t.4$Taxon <- envt.mat.2$Taxon
cazy.t.5 <- melt(cazy.t.4, id.vars = "Taxon")
cazy.t.5$Exploration <- envt.mat.2$Exploration[match(cazy.t.5$Taxon, envt.mat.2$Taxon)]
  
ggplot(cazy.t.5, aes(x = variable, y = value, color = Exploration))+
  geom_boxplot()


##########################
########PFAMs#############
##########################
pfams$Annotation.Description <- NULL
pfams.t <- data.frame(t(pfams))
pfams.t <- pfams.t[rowSums(pfams.t[])>0,] #remove taxa not included
pfams.t <- pfams.t[, colSums(pfams.t != 0) > 0] #remove empty pfams

#Now let's divide everything by the total number of PFAMs (so column 1)
pfams.t.r <- pfams.t/pfams.t[,1]
pfams.t.r$PFAMs <- NULL

#Make envt dataframe 
envt.mat <- data.frame(Taxon = row.names(pfams.t.r))
envt.mat$Exploration <- info$Exploration_type[match(envt.mat$Taxon, info$TaxonID)]

#Now remove any non-assigned taxa
pfams.t.r$exploration <- envt.mat$Exploration[match(row.names(pfams.t.r), envt.mat$Taxon)]
pfams.t.r <- pfams.t.r[!is.na(pfams.t.r$exploration),]

envt.mat.2 <- data.frame(Exploration = pfams.t.r$exploration, Taxon = row.names(pfams.t.r))
pfams.t.r$exploration <- NULL

#################################################################
####################Constrained approach#########################
#################################################################
#RDA--
bray.dbrda.thing<- capscale(vegdist(pfams.t.r, method = "bray") ~ Exploration, data = envt.mat.2)
sum.bray <- summary(bray.dbrda.thing)
anova(bray.dbrda.thing)

#Let's visualize the difference
biplot.stuff <- data.frame(sum.bray$sites)
biplot.stuff$Exploration <- info$Exploration[match(row.names(biplot.stuff), info$TaxonID)]
biplot.stuff$Genus <- info$Genus[match(row.names(biplot.stuff), info$TaxonID)] 
biplot.stuff$Higher_clade <- ftraits$higher_clade[match(biplot.stuff$Genus, ftraits$Genus)]
biplot.stuff$Published <- info$Published[match(row.names(biplot.stuff), info$TaxonID)]
biplot.stuff$Published <- ifelse(biplot.stuff$Published == "", "Unpublished", "Published")

biplot.stuff$Exploration <- factor(biplot.stuff$Exploration, levels = c("C", "SD", "MD-Smooth", "MD-Fringe", "MD-Mat", "LD"))
biplot.stuff$Published <- factor(biplot.stuff$Published, levels = c("Unpublished", "Published"))

#Now visualize
ggplot(biplot.stuff, aes(x = CAP1, y = CAP2, shape = Higher_clade, color = Exploration, alpha = Published)) + 
  geom_point(size = 4) + theme_classic()+
  labs(x = "CAP1 (48%)", y = "CAP2 (39%)", color = "", shape = "", alpha = "")

#################################################################
####################exploratory approach#########################
#################################################################

#NMDS---
meta.bray <- pcoa(vegdist(pfams.t.r, type = "jaccard"))
biplot.stuff.2 <- data.frame(meta.bray$vectors[,1:2])
biplot.stuff.2$Exploration <- envt.mat.2$Exploration[match(row.names(biplot.stuff.2), envt.mat.2$Taxon)]
biplot.stuff.2$Genus <- info$Genus[match(row.names(biplot.stuff.2), info$TaxonID)]
biplot.stuff.2$Assembly.Length <- info$Assembly.Length[match(row.names(biplot.stuff.2), info$TaxonID)]
biplot.stuff.2$X..Genes <- info$X..Genes[match(row.names(biplot.stuff.2), info$TaxonID)]
biplot.stuff.2$growth_form_fg <- ftraits$growth_form_fg[match(biplot.stuff.2$Genus, ftraits$Genus)]
biplot.stuff.2$Higher_clade <- ftraits$higher_clade[match(biplot.stuff.2$Genus, ftraits$Genus)]

#PERMANOVA---
adonis2(vegdist(pfams.t.r, method = "bray") ~ Exploration + Higher_clade, data = biplot.stuff.2)

#Now visualize
ggplot(biplot.stuff.2, aes(x = Axis.1, y = Axis.2, color = Exploration, shape = Higher_clade)) + 
  geom_point(size = 2) + theme_classic()+
  labs(x = "PCoA1 (38%)", y = "PCoA2 (14%)", shape = "Phylum", color = "Exp. type")+
  theme(aspect.ratio = 1)

#Now perform a different type of cluster analysis that links specific PFAMs to the groups we can see appearing
biplot.stuff.2$Cluster <- paste0(ifelse(biplot.stuff.2$Axis.1 < 0, "Cluster_1", "Cluster_2"), "_", biplot.stuff.2$Higher_clade, "_", biplot.stuff.2$Exploration)

biplot.stuff.2$Cluster <- gsub("Cluster_1_Ascomycota_SD", "Low biomass Asco 1", biplot.stuff.2$Cluster)
biplot.stuff.2$Cluster <- gsub("Cluster_1_Ascomycota_C", "Low biomass Asco 1", biplot.stuff.2$Cluster)
biplot.stuff.2$Cluster <- gsub("Cluster_2_Ascomycota_SD", "Low biomass Asco 2", biplot.stuff.2$Cluster)
biplot.stuff.2$Cluster <- gsub("Cluster_2_Ascomycota_C", "Low biomass Asco 2", biplot.stuff.2$Cluster)

biplot.stuff.2$Cluster <- gsub("Cluster_1_Basidiomycota_SD", "Low biomass Basid 1", biplot.stuff.2$Cluster)
biplot.stuff.2$Cluster <- gsub("Cluster_1_Basidiomycota_C", "Low biomass Basid 1", biplot.stuff.2$Cluster)

biplot.stuff.2$Cluster <- gsub("Cluster_2_Basidiomycota_SD", "Low biomass Basid 2", biplot.stuff.2$Cluster)
biplot.stuff.2$Cluster <- gsub("Cluster_2_Basidiomycota_C", "Low biomass Basid 2", biplot.stuff.2$Cluster)

biplot.stuff.2$Cluster <- gsub("Cluster_1_Basidiomycota_MD-Fringe", "MD Basid 1", biplot.stuff.2$Cluster)
biplot.stuff.2$Cluster <- gsub("Cluster_1_Basidiomycota_MD-Mat", "MD Basid 1", biplot.stuff.2$Cluster)
biplot.stuff.2$Cluster <- gsub("Cluster_1_Basidiomycota_MD-Smooth", "MD Basid 1", biplot.stuff.2$Cluster)

biplot.stuff.2$Cluster <- gsub("Cluster_2_Basidiomycota_MD-Fringe", "MD Basid 2", biplot.stuff.2$Cluster)
biplot.stuff.2$Cluster <- gsub("Cluster_2_Basidiomycota_MD-Mat", "MD Basid 2", biplot.stuff.2$Cluster)
biplot.stuff.2$Cluster <- gsub("Cluster_2_Basidiomycota_MD-Smooth", "MD Basid 2", biplot.stuff.2$Cluster)

biplot.stuff.2$Cluster <- gsub("Cluster_1_Basidiomycota_LD", "LD Basid 1", biplot.stuff.2$Cluster)

biplot.stuff.2$Cluster <- gsub("Cluster_2_Basidiomycota_LD", "LD Basid 2", biplot.stuff.2$Cluster)

unique(biplot.stuff.2$Cluster)

#Now, let's visualize with this type of cateogorization
#Now visualize
ggplot(biplot.stuff.2, aes(x = Axis.1, y = Axis.2, color = Cluster)) + 
  geom_point(size = 2) + theme_classic()+
  labs(x = "PCoA1 (38%)", y = "PCoA2 (14%)", shape = "Phylum", color = "Exp. type")+
  theme(aspect.ratio = 1)

identical(row.names(pfams.t.r), row.names(biplot.stuff.2))

#################################################################
###################Indicator sp. analysis########################
#################################################################
pfam.indval <- multipatt(pfams.t.r, biplot.stuff.2$Cluster, func = "IndVal",duleg = TRUE,
                    control = how(nperm=999))

#Get summary
summary(pfam.indval, indvalcomp = TRUE)

#Now look at the results and add the annnotation
pfam.indval.results <- pfam.indval$sign
pfam.indval.results <- subset(pfam.indval.results, p.value<0.05)

#Add annotation
pfam.indval.results$Annotation <- pfams.2$Annotation.Description[match(row.names(pfam.indval.results),
                                                                       row.names(pfams.2))]

#Remove any pfams without annotation because they are useless
pfam.indval.results <- pfam.indval.results[!pfam.indval.results$Annotation == "", ]





#Make a way to compare using word clouds

#LDB2
ldb2 <- data.frame(Group = pfam.indval.results$`s.LD Basid 2`, Anno = pfam.indval.results$Annotation)
ldb2 <- ldb2[!ldb2$Group == 0, ]
ldb2 <- Corpus(VectorSource(ldb2$Anno))

dtm <- TermDocumentMatrix(ldb2) 
matrix <- as.matrix(dtm) 
words <- sort(rowSums(matrix),decreasing=TRUE) 
df <- data.frame(word = names(words),freq=words)

ldb2.wc <- wordcloud(words = df$word, freq = df$freq, min.freq = 1,
          max.words=400, random.order=FALSE, rot.per=0.35,scale=c(3.5,0.25),
          colors=brewer.pal(8, "Dark2"))

#LbA1
lba1 <- data.frame(Group = pfam.indval.results$`s.Low biomass Asco 1`, Anno = pfam.indval.results$Annotation)
lba1 <- lba1[!lba1$Group == 0, ]
lba1 <- Corpus(VectorSource(lba1$Anno))

dtm <- TermDocumentMatrix(lba1) 
matrix <- as.matrix(dtm) 
words <- sort(rowSums(matrix),decreasing=TRUE) 
df <- data.frame(word = names(words),freq=words)

lba1.wc <- wordcloud(words = df$word, freq = df$freq, min.freq = 1,
                     max.words=400, random.order=FALSE, rot.per=0.35,scale=c(3.5,0.25),
                     colors=brewer.pal(8, "Dark2"))

#LbA2
lba2 <- data.frame(Group = pfam.indval.results$`s.Low biomass Asco 2`, Anno = pfam.indval.results$Annotation)
lba2 <- lba2[!lba2$Group == 0, ]
lba2 <- Corpus(VectorSource(lba2$Anno))

dtm <- TermDocumentMatrix(lba2) 
matrix <- as.matrix(dtm) 
words <- sort(rowSums(matrix),decreasing=TRUE) 
df <- data.frame(word = names(words),freq=words)

lba2.wc <- wordcloud(words = df$word, freq = df$freq, min.freq = 1,
                     max.words=400, random.order=FALSE, rot.per=0.35,scale=c(3.5,0.25),
                     colors=brewer.pal(8, "Dark2"))



#MDB1 
mdb1 <- data.frame(Group = pfam.indval.results$`s.MD Basid 1`, Anno = pfam.indval.results$Annotation)
mdb1 <- mdb1[!mdb1$Group == 0, ]
mdb1 <- Corpus(VectorSource(mdb1$Anno))

dtm <- TermDocumentMatrix(mdb1) 
matrix <- as.matrix(dtm) 
words <- sort(rowSums(matrix),decreasing=TRUE) 
df <- data.frame(word = names(words),freq=words)

mdb1.wc <- wordcloud(words = df$word, freq = df$freq, min.freq = 1,
                     max.words=400, random.order=FALSE, rot.per=0.35,scale=c(3.5,0.25),
                     colors=brewer.pal(8, "Dark2"))


#Now visualize these results using a Venn diagram
df <- list(
LD_Basidio_1 = ifelse(pfam.indval.results$`s.LD Basid 1` == 1, row.names(pfam.indval.results), NA),
LD_Basidio_2 = ifelse(pfam.indval.results$`s.LD Basid 2` == 1, row.names(pfam.indval.results), NA),
LB_Asco_1 = ifelse(pfam.indval.results$`s.Low biomass Asco 1` == 1, row.names(pfam.indval.results), NA),
LB_Asco_2 = ifelse(pfam.indval.results$`s.Low biomass Asco 2` == 1, row.names(pfam.indval.results), NA),
LB_Basidio_1 = ifelse(pfam.indval.results$`s.Low biomass Basid 1` == 1, row.names(pfam.indval.results), NA),
LB_Basidio_2 = ifelse(pfam.indval.results$`s.Low biomass Basid 2` == 1, row.names(pfam.indval.results), NA),
MD_Basidio_1 = ifelse(pfam.indval.results$`s.MD Basid 1` == 1, row.names(pfam.indval.results), NA),
MD_Basidio_2 = ifelse(pfam.indval.results$`s.MD Basid 2` == 1, row.names(pfam.indval.results), NA)
)

#What are the cluster 1 and cluster 2 differences within groups
df <- list(
  LD_Basidio_1 = df$LD_Basidio_1[!is.na(df$LD_Basidio_1)],
  LD_Basidio_2 = df$LD_Basidio_2[!is.na(df$LD_Basidio_2)],
  LB_Asco_1 = df$LB_Asco_1[!is.na(df$LB_Asco_1)],
  LB_Asco_2 = df$LB_Asco_2[!is.na(df$LB_Asco_2)],
  LB_Basidio_1 = df$LB_Basidio_1[!is.na(df$LB_Basidio_1)],
  LB_Basidio_2 = df$LB_Basidio_2[!is.na(df$LB_Basidio_2)],
  MD_Basidio_1 = df$MD_Basidio_1[!is.na(df$MD_Basidio_1)],
  MD_Basidio_2 = df$MD_Basidio_2[!is.na(df$MD_Basidio_2)]
)

#######################################
#####Low biomass asco differences######
#######################################
LB.asco.diffs.cluster.1 <- data.frame(Differences = setdiff(df$LB_Asco_1, df$LB_Asco_2))
LB.asco.diffs.cluster.1$Annotation <- pfams.2$Annotation.Description[match(LB.asco.diffs.cluster.1$Differences, row.names(pfams.2))]
LB.asco.diffs.cluster.1$IndVal <- pfam.indval.results$stat[match(LB.asco.diffs.cluster.1$Differences, row.names(pfam.indval.results))]

LB.asco.diffs.cluster.2 <- data.frame(Differences = setdiff(df$LB_Asco_2, df$LB_Asco_1))
LB.asco.diffs.cluster.2$Annotation <- pfams.2$Annotation.Description[match(LB.asco.diffs.cluster.2$Differences, row.names(pfams.2))]
LB.asco.diffs.cluster.2$IndVal <- pfam.indval.results$stat[match(LB.asco.diffs.cluster.2$Differences, row.names(pfam.indval.results))]

#######################################
#####Low biomass Basidio differences######
#######################################
LB.basidio.diffs.cluster.1 <- data.frame(Differences = setdiff(df$LB_Basidio_1, df$LB_Basidio_2))
LB.basidio.diffs.cluster.1$Annotation <- pfams.2$Annotation.Description[match(LB.basidio.diffs.cluster.1$Differences, row.names(pfams.2))]
LB.basidio.diffs.cluster.1$IndVal <- pfam.indval.results$stat[match(LB.basidio.diffs.cluster.1$Differences, row.names(pfam.indval.results))]

LB.basidio.diffs.cluster.2 <- data.frame(Differences = setdiff(df$LB_Basidio_2, df$LB_Basidio_1))
LB.basidio.diffs.cluster.2$Annotation <- pfams.2$Annotation.Description[match(LB.basidio.diffs.cluster.2$Differences, row.names(pfams.2))]
LB.basidio.diffs.cluster.2$IndVal <- pfam.indval.results$stat[match(LB.basidio.diffs.cluster.2$Differences, row.names(pfam.indval.results))]

#######################################
########LD Basidio differences#########
#######################################
LD.basidio.diffs.cluster.1 <- data.frame(Differences = setdiff(df$LD_Basidio_1, df$LD_Basidio_2))
LD.basidio.diffs.cluster.1$Annotation <- pfams.2$Annotation.Description[match(LD.basidio.diffs.cluster.1$Differences, row.names(pfams.2))]
LD.basidio.diffs.cluster.1$IndVal <- pfam.indval.results$stat[match(LD.basidio.diffs.cluster.1$Differences, row.names(pfam.indval.results))]

LD.basidio.diffs.cluster.2 <- data.frame(Differences = setdiff(df$LD_Basidio_2, df$LD_Basidio_1))
LD.basidio.diffs.cluster.2$Annotation <- pfams.2$Annotation.Description[match(LD.basidio.diffs.cluster.2$Differences, row.names(pfams.2))]
LD.basidio.diffs.cluster.2$IndVal <- pfam.indval.results$stat[match(LD.basidio.diffs.cluster.2$Differences, row.names(pfam.indval.results))]

#######################################
########MD Basidio differences#########
#######################################
MD.basidio.diffs.cluster.1 <- data.frame(Differences = setdiff(df$MD_Basidio_1, df$MD_Basidio_2))
MD.basidio.diffs.cluster.1$Annotation <- pfams.2$Annotation.Description[match(MD.basidio.diffs.cluster.1$Differences, row.names(pfams.2))]
MD.basidio.diffs.cluster.1$IndVal <- pfam.indval.results$stat[match(MD.basidio.diffs.cluster.1$Differences, row.names(pfam.indval.results))]

MD.basidio.diffs.cluster.2 <- data.frame(Differences = setdiff(df$MD_Basidio_2, df$LD_Basidio_1))
MD.basidio.diffs.cluster.2$Annotation <- pfams.2$Annotation.Description[match(MD.basidio.diffs.cluster.2$Differences, row.names(pfams.2))]
MD.basidio.diffs.cluster.2$IndVal <- pfam.indval.results$stat[match(MD.basidio.diffs.cluster.2$Differences, row.names(pfam.indval.results))]

















#Visualization
ggVennDiagram(df[c("LB_Basidio_1", "LB_Basidio_2", "LB_Asco_1", "LB_Asco_2")], label_alpha = 0,
              category.names = c("Bas 1", "Bas 2", "Asco 1", "Asco 2")) +
  scale_fill_gradient(low="blue",high = "yellow")
