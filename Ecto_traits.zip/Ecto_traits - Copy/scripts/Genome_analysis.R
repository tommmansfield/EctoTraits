#Assess how PFAM and CAYymes  vary with exploration type

#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

#Load packages
require(ape)
require(fungaltraits)
require(splitstackshape)
require(vegan)
require(ggplot2)

#Read in fungal trait data scraped from mycocosm
cazy <- read.csv("/Users/marka.anthony/Documents/R_projects/Ecto_traits/Ecto_traits/data_storage/raw_data/CAZymes.csv", row.names = 1)
info <- read.csv("/Users/marka.anthony/Documents/R_projects/Ecto_traits/Ecto_traits/data_storage/raw_data/Mycocosm_names_meta_data.csv")
ftraits <- fungal_traits()

#Add the genus level ID for trait assignment and assign exploration types
info$species <- info$Name
new.d <- cSplit(info, "Name", sep = " ")
info$species <- NULL
info$genus <- new.d$Name_1
unique(ftraits$em_expl)
unique(ftraits$em_text)
info$exploration <- ftraits$em_expl[match(info$genus, ftraits$Genus)]
info$exploration.2 <- ftraits$em_text[match(info$genus, ftraits$Genus)]
info <- read.csv("/Users/marka.anthony/Documents/R_projects/Ecto_traits/Ecto_traits/data_storage/raw_data/fungal.information.csv")

#Now, let's take a look using RDA
cazy$Annotation.Description <- NULL
cazy.t <- data.frame(t(cazy))
cazy.t <- cazy.t[rowSums(cazy.t[])>0,] #remove taxa not included

#Make envt dataframe 
envt.mat <- data.frame(Taxon = row.names(cazy.t))
envt.mat$Exploration <- info$Exploration_type[match(envt.mat$Taxon, row.names(cazy.t))]

#Now remove any non-assigned taxa
cazy.t$exploration <- envt.mat$Exploration
cazy.t <- cazy.t[!is.na(cazy.t$exploration),]
envt.mat.2 <- data.frame(Exploration = cazy.t$exploration, Taxon = row.names(cazy.t))
cazy.t$exploration <- NULL

#Now we can run the model and any taxa without an exploration type will be dropped
unique(envt.mat.2$Exploration)
#Now make the RDA
bray.dbrda.thing<- capscale(vegdist(wisconsin(cazy.t), method = "bray") ~ Exploration, data = envt.mat.2)
summary(bray.dbrda.thing)
anova(bray.dbrda.thing)
bray.dbrda.thing

#Do a permanova
adonis2(vegdist(wisconsin(cazy.t), method = "bray") ~ Exploration, data = envt.mat.2)
   
#Let's visualize the difference
biplot.stuff <- data.frame(bray.dbrda.thing$CCA$u)
biplot.stuff$Exploration <- envt.mat.2$Exploration

#Now visualize
ggplot(biplot.stuff, aes(x = CAP1, y = CAP2, color = Exploration)) + 
  geom_point() + theme_classic()


#Let's se
