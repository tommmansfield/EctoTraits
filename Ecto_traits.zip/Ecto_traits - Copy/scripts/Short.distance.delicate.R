# Model the relative abundances of exploration types ----
  

  #clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

require(dplyr); require(tidyr); require(data.table); require(splitstackshape); require(pls)
require(reshape2); require(cowplot); require(ggplot2); require(chillR)

icp.dat <- read.csv(icp.data.envt)
isme.explorers.2 <- readRDS(isme.explore.2.new.fungal.traits)
isme.explorers <- readRDS(isme.explore)
soil.explorers <- readRDS(soil.explore)
soil.exploreres.2 <- readRDS(soil.explore.2.new.fungal.traits)


#Combine the env't and species matrices
isme.explorers.w.envt <- merge(isme.explorers, icp.dat, by = "country_plot")

#Fix stand age variable
isme.explorers.w.envt$Stand.age <- as.numeric(as.character(gsub(".9", ".0", isme.explorers.w.envt$Stand.age)))

#Make a new variable that is the foliar p:n ratio
isme.explorers.w.envt$p.n <- isme.explorers.w.envt$p/isme.explorers.w.envt$n

#Now let's build the models to predict short-distance delicate relative abundances ----

#fit short distance-delicate model
sd.d <- plsr(short.distance_delicate ~ log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + M01.pH + log(mg_C_ha_yr)*Tree_type + lat+ N_dep_2019 + Stand.age +
             MAT + MAP + clay_0.5cm_mean, 
           data=isme.explorers.w.envt, 
           scale=TRUE, validation="CV", method = "oscorespls")

summary(sd.d) 

#Visualize cross-validation plots
validationplot(sd.d, val.type="MSEP")
hist(sd.d$residuals)
qqnorm(sd.d$residuals) # nice!

#look at variable importance in the projection scores (ViP)
VIP(sd.d)

# What if we remove the least informative variables ViP < 0.8 on Comp 1-3?  
# pH, tree growth, N_dep_2019, MAT, MAP, clay_0.5cm_mean
sd.d.2 <- plsr(short.distance_delicate ~ log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + log(mg_C_ha_yr)*Tree_type + 
                 lat + Stand.age, 
             data=isme.explorers.w.envt, 
             scale=TRUE, validation="CV", method = "oscorespls")

summary(sd.d.2) 
summary(sd.d)

#Visualize cross-validation plots
validationplot(sd.d.2, val.type="MSEP")
hist(sd.d.2$residuals)
qqnorm(sd.d.2$residuals)

#look at variable importance in the projection scores (ViP)
VIP(sd.d.2)
plot(sd.d.2, ncomp = 3, asp = 1, line = TRUE) #Looks ok

#Now try to predict new observations
sd.d.2.predict <- predict(sd.d.2, ncomp = 3, newdata = isme.explorers.w.envt[1:50,], na.action = "na.omit")
sd.d.2.subset <- (isme.explorers.w.envt[rownames(isme.explorers.w.envt) %in% row.names(sd.d.2.predict), ])

#Now calculate the root mean sqare error (RMSE) - the average deviation between the predicted rel. abund. and observed
sqrt(mean((sd.d.2.predict - sd.d.2.subset$short.distance_delicate)^2))

#Now plot the VIF scores for Comps 1, 2, and 3
sd.d.2.vip <- data.frame(VIP(sd.d.2))
sd.d.2.vip.df <- data.frame(Comp = c(rep(c("Comp1","Comp2","Comp3"), 10)),
                            Factor = c(rep("Foliar N", 3),
                                       rep("Tree type", 3), 
                                       rep("Foliar P:N", 3), 
                                       rep("Soil N stocks", 3),
                                       rep("Forest productivity", 3),
                                       rep("Latitude", 3),
                                       rep("Stand age", 3),
                                       rep("Foliar N x Tree type", 3), 
                                       rep("Foliar P:N x Tree type", 3),
                                       rep("Forest productivity x Tree type", 3)),
                            VIP = c(sd.d.2.vip$log.n.[1:3],
                                    sd.d.2.vip$Tree_typeconifers[1:3],
                                    sd.d.2.vip$log.p.n.[1:3],
                                    sd.d.2.vip$log.Mineral.Nitrogen.Stock.[1:3],
                                    sd.d.2.vip$log.mg_C_ha_yr.[1:3],
                                    sd.d.2.vip$lat[1:3],
                                    sd.d.2.vip$Stand.age[1:3],
                                    sd.d.2.vip$log.n..Tree_typeconifers[1:3],
                                    sd.d.2.vip$Tree_typeconifers.log.p.n.[1:3],
                                    sd.d.2.vip$Tree_typeconifers.log.mg_C_ha_yr.[1:3]))

sd.d.vip.plot <- ggplot(sd.d.2.vip.df, aes(x = reorder(Factor,VIP), y = VIP))+
  geom_bar(stat = 'identity', show.legend = FALSE)+
  theme_classic()+
  coord_flip()+
  labs(x = "", y = "")+
  scale_fill_manual(values = c("orange", "blue"))  


# DON'T RUN THIS UNLESS MAKING THE PLOTS FOR A PANEL AND NEEDING TO GO TO THE NEXT SCRIPT!!!!!
# For plotting purposes only since making the plots from multiple scripts:
# rm(list=setdiff(ls(), c("cm.f.vip.plot", "sd.d.vip.plot", "sd.c.vip.plot", 
#                       "md.s.vip.plot", "md.f.vip.plot", "lm.vip.plot")))


# Get stats!----

#Now split these out by tree type to isolate the conifer effects
isme.explorers.w.envt.sp <- split(isme.explorers.w.envt, isme.explorers.w.envt$Tree_type)

#this function will remove infinite values
inf2NA <- function(x) { x[is.infinite(x)] <- NA; x }

# check tree type comparison
kruskal.test(isme.explorers.w.envt$short.distance_delicate, isme.explorers.w.envt$Tree_type)

# broad:conifer ratio = 0.4644809
mean(isme.explorers.w.envt.sp$broadleaves$short.distance_delicate)/mean(isme.explorers.w.envt.sp$conifers$short.distance_delicate)


# short.distance_delicate ~ log(n)*Tree_type + log(p.n)*Tree_type + log(Mineral.Nitrogen.Stock) + log(mg_C_ha_yr)*Tree_type + 
#                           lat + Stand.age 

# Broadleaves
cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$short.distance_delicate*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$n)), use="pairwise.complete.obs") # cor -0.2822472 (n/s 0.06342)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$short.distance_delicate*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$p.n)), use="pairwise.complete.obs") # cor 0.08217014 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$short.distance_delicate*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$lat)), use="pairwise.complete.obs") # cor -0.2116612 (n/s)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$broadleaves$short.distance_delicate*100)), 
         scale(log(isme.explorers.w.envt.sp$broadleaves$Stand.age)), use="pairwise.complete.obs") # cor -0.03114717 (n/s)

# Conifers
cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$short.distance_delicate*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$n)), use="pairwise.complete.obs") # cor 0.336536 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$short.distance_delicate*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$p.n)), use="pairwise.complete.obs") # cor -0.2358949 (n/s 0.6722)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$short.distance_delicate*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$lat)), use="pairwise.complete.obs") # cor -0.4344516 (significant)

cor.test(inf2NA(log(isme.explorers.w.envt.sp$conifers$short.distance_delicate*100)), 
         scale(log(isme.explorers.w.envt.sp$conifers$Stand.age)), use="pairwise.complete.obs") # cor -0.2654945 (significant)



