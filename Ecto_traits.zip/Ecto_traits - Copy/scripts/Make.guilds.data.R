#Now make a dataset on saprotrophic and pathogenic fungi -- relative abundances, richness, and compositions

#Make datasets of fungal data ----

#clear environment, load paths + packages.----
rm(list=ls())
source('paths.file.r')

require(dplyr)
require(tidyr)
require(fungaltraits)
require(data.table)
require(splitstackshape)
require(vegan)
require(fungaltraits)

#Set names of output files to save
guild.data.frame.save <- saprotroph.save

#Upload the fungal data
otu.tab <- read.csv(isme.ectos, row.names = 1)
envt.tab <- read.csv(isme.envt, row.names = 1)
tax.tab <- read.csv(isme.ectos.tax)
trait.tab <- read.csv(isme.traits)
fungal.traits <- fungal_traits()
soil.tab <- as.data.frame(fread(icpf.fungi, sep = '\t'))
soil.envt.tab <- read.csv(icpf.envt.mat)
soil.funguild.tab <- fread(icpf.funguild.mat, sep = '\t')
soil.tax.tab <- read.csv(icpf.tax, sep = '\t', header = FALSE)
soil.tax.tab <- data.frame(cSplit(soil.tax.tab, 'V2', sep = ";", type.convert = FALSE))


#. 1 add trophic mode (saprotroph versus pathogenic)

#First do this for the ISME 2022 data
otu.tax <- data.frame(Label = colnames(otu.tab))
otu.tax$Genus <- tax.tab$Genus[match(otu.tax$Label, tax.tab$Label)]
otu.tax$Species <- tax.tab$Species[match(otu.tax$Label, tax.tab$Label)]
otu.tax$Family <- tax.tab$Family[match(otu.tax$Label, tax.tab$Label)]
otu.tax$SH <- tax.tab$Taxonomy[match(otu.tax$Label, tax.tab$Label)]
otu.tax$Guild <- fungal.traits$guild_fg[match(otu.tax$Genus, fungal.traits$Genus)]

#Now add data on functional group for soils data only....

#Now do this for the ICPF Microbiome data
soil.otu.tax <- data.frame(OTU = soil.tab$`#OTU ID`)
soil.otu.tax$Genus <- soil.tax.tab$V2_6[match(soil.otu.tax$OTU, soil.tax.tab$V1)]
soil.otu.tax$Genus <- gsub("g__", "",soil.otu.tax$Genus)
soil.otu.tax$Species <- soil.tax.tab$V2_7[match(soil.otu.tax$OTU, soil.tax.tab$V1)]
soil.otu.tax$Family <- soil.tax.tab$V2_5[match(soil.otu.tax$OTU, soil.tax.tab$V1)]
soil.otu.tax$Guild <- fungal.traits$guild_fg[match(soil.otu.tax$Genus, fungal.traits$Genus)]

#. 2 clean up the soil species rel. abund. matrix
#ISME is already sorted/rarified, but we need to do this first for soil

########--------------------------------------------------------------------
##Non ICP samples to remove
otu.tab2 <- soil.tab
row.names(otu.tab2) <- otu.tab2$`#OTU ID`
otu.tab2$`#OTU ID` <- NULL
otu.tab2$S_364 <- NULL
otu.tab2$S_365<- NULL
otu.tab2$S_366<- NULL
otu.tab2$S_367<- NULL
otu.tab2$S_368<- NULL
otu.tab2$S_369<- NULL
otu.tab2$S_370<- NULL
otu.tab2$S_371<- NULL
otu.tab2$S_372<- NULL
otu.tab2$S_373<- NULL
otu.tab2$S_374<- NULL
otu.tab2$S_376<- NULL
otu.tab2$S_4<- NULL
otu.tab2$S_11<- NULL
otu.tab2$S_292<- NULL
otu.tab2$S_293<- NULL
otu.tab2$S_325<- NULL
otu.tab2$S_329<- NULL
otu.tab2$S_340<- NULL
otu.tab2$S_358<- NULL
otu.tab2$X2.S_29_2019<- NULL
otu.tab2$X2.S_41_2019<- NULL
otu.tab2$S_115_2019<- NULL
otu.tab2$X2.S_54_2019<- NULL
otu.tab2$X2.S_102_2019<- NULL
otu.tab2$X2.S_107_2019<- NULL
otu.tab2$X2.S_108_2019<- NULL
otu.tab2$X2.S_109_2019<- NULL
otu.tab2$X2.S_110_2019<- NULL
otu.tab2$X2.S_111_2019<- NULL
otu.tab2$X2.S_112_2019<- NULL
otu.tab2$S_15_2019<- NULL
otu.tab2$S_22_2019<- NULL
otu.tab2$S_29_2019<- NULL
otu.tab2$S_36_2019<- NULL
otu.tab2$S_46_2019<- NULL
otu.tab2$S_56_2019<- NULL
otu.tab2$S_71_2019<- NULL
otu.tab2$X2.S_57_2019<- NULL

#Now lets look at column sums
otu.tab2 <- data.frame(t(otu.tab2))

#Remove samples with <1000 sequences --  
high.depth.otu<- subset(otu.tab2, rowSums(otu.tab2) > 1000)

#We need to rarefy to the lowest sequencing depth
play <- rrarefy(as.matrix(high.depth.otu), (min(rowSums(high.depth.otu))-1))

#Make proportional
play<- data.frame(prop.table(as.matrix(high.depth.otu), 1))

#Remove OTUS without any values >0
play2<- play[, which(colSums(play) != 0)]

#Add the guild annotaiton to each otu and summarize
play2 <- data.frame(t(play2))
play2$guild <- soil.otu.tax$Guild[match(row.names(play2), soil.otu.tax$OTU)]
form.list<- play2$guild

play2$guild <- NULL
att1 <- aggregate(. ~  form.list, data= play2, FUN = "sum")
row.names(att1) = att1$form.list
att1$form.list<- NULL
guild.data.frame <- data.frame(t(att1))
guild.data.frame$unknown <- guild.data.frame$NULL.
guild.data.frame$NULL. <- NULL

#Now save this data frame
saveRDS(guild.data.frame, guild.data.frame.save)
